/*
 * Copyright (c) Contributors, http://opensimulator.org/
 * See CONTRIBUTORS.TXT for a full list of copyright holders.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the OpenSimulator Project nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE DEVELOPERS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Text;
using System.Threading;
using log4net;
using Mono.Addins;
using Nini.Config;
using OpenMetaverse;
using OpenSim.Framework;
using OpenSim.Region.Framework.Interfaces;
using OpenSim.Region.Framework.Scenes;
using OpenSim.Region.PhysicsModules.SharedBase;

namespace OpenSim.Region.OptionalModules.World.Weather
{
    [Extension(Path = "/OpenSim/RegionModules", NodeName = "RegionModule", Id = "WeatherModule")]
    public class WeatherModule : INonSharedRegionModule
    {
        private enum WeatherKind
        {
            Clear,
            Sunny,
            Rain,
            Storm,
            Snow,
            Blizzard
        }

        private enum CoverageMode
        {
            Region,
            ActiveArea,
            Wandering
        }

        private enum SurfaceKind
        {
            Puddle,
            Snow
        }

        private sealed class EnvironmentProfile
        {
            public float CloudCoverage;
            public float CloudScale;
            public Vector4 CloudColor;
            public Vector3 CloudXYDensity;
            public Vector3 CloudDetailXYDensity;
            public float CloudScrollX;
            public float CloudScrollY;
            public Vector4 Horizon;
            public Vector4 BlueDensity;
            // Multipliers applied to the CURRENT environment's own values,
            // not absolute replacements - real weather darkens/brightens
            // whatever daylight already exists, it doesn't replace day with
            // night or erase the admin's own tuned look and the region's
            // real day/night cycle. Cloud*/Horizon/BlueDensity/Haze*/
            // Density/DistanceMultiplier/SunGlow* stay absolute below since
            // those genuinely ARE what the weather is, not a brightness
            // question. StarBrightness is deliberately left out entirely -
            // weather never touches it, so night stars are never erased.
            public float AmbientMultiplier = 1f;
            public float SunMoonColorMultiplier = 1f;
            public float SceneGammaMultiplier = 1f;
            public float HazeHorizon;
            public float HazeDensity;
            public float DensityMultiplier;
            public float DistanceMultiplier;
            public float SunGlowFocus;
            public float SunGlowSize;
            public bool DrawClassicClouds = true;
            public bool CloudScrollXLock;
            public bool CloudScrollYLock;

            public EnvironmentProfile Clone()
            {
                return (EnvironmentProfile)MemberwiseClone();
            }
        }

        private sealed class SurfacePatch
        {
            public SurfaceKind Kind;
            public SceneObjectGroup Group;
        }

        private sealed class SurfaceCandidate
        {
            public SurfaceKind Kind;
            public Vector3 Position;
            public float Size;
            public float Level;
        }

        private sealed class ExclusionVolume
        {
            public float MinX;
            public float MaxX;
            public float MinY;
            public float MaxY;
            public float MinZ;
            public float MaxZ;

            public bool ContainsXY(float x, float y)
            {
                return x >= MinX && x <= MaxX
                    && y >= MinY && y <= MaxY;
            }
        }

        private const string GeneratedNamePrefix = "OpenSimWeather:";
        private const string GeneratedDescription = "Temporary object generated by OpenSimWeather. Do not save.";

        // PSYS_SRC_BURST_RADIUS is only meaningful up to 50m; viewers clamp/misrender
        // beyond that. Emitter radius is derived from region-size-proportional spacing,
        // so on var regions (1024m+) it must be capped or particles stop rendering sane
        // patterns near the emitter.
        private const float MaxParticleBurstRadius = 50f;

        private const uint ParticleFlags =
            1u |    // PSYS_PART_INTERP_COLOR_MASK
            2u |    // PSYS_PART_INTERP_SCALE_MASK
            8u |    // PSYS_PART_WIND_MASK
            256u;   // PSYS_PART_EMISSIVE_MASK

        private static readonly ILog m_log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        private readonly object m_sync = new object();
        private readonly object m_weatherChangeSync = new object();
        private readonly object m_randomSync = new object();
        private readonly List<SceneObjectGroup> m_emitters = new List<SceneObjectGroup>();
        private readonly List<WeatherKind> m_autoCycleChoices = new List<WeatherKind>();
        private readonly Random m_random = new Random();

        private Scene m_scene;
        private bool m_enabled;
        private bool m_estateManagerOnly;
        private int m_commandChannel;
        private CoverageMode m_coverageMode;
        private int m_emitterGrid;
        private float m_emitterSpacingMeters;
        private int m_maxEmitters;
        private float m_activeAreaRadiusMeters;
        private int m_activeAreaRefreshSeconds;
        private int m_wanderingBatchSize;
        private int m_wanderingRefreshSeconds;
        private float m_wanderingChurnFraction;
        private Timer m_wanderingTimer;
        private int m_wanderingBusy;
        private float m_emitterRadiusScale;
        private float m_emitterHeight;
        private float m_intensity;
        private UUID m_rainTexture = Util.BLANK_TEXTURE_UUID;
        private UUID m_stormTexture = Util.BLANK_TEXTURE_UUID;
        private UUID m_snowTexture = Util.BLANK_TEXTURE_UUID;
        private UUID m_blizzardTexture = Util.BLANK_TEXTURE_UUID;
        private UUID m_lightningTexture = Util.BLANK_TEXTURE_UUID;
        private Timer m_activeAreaTimer;
        private int m_activeAreaBusy;
        private UUID m_weatherOwnerId = UUID.Zero;
        private readonly Dictionary<long, SceneObjectGroup> m_activeEmitterCells = new Dictionary<long, SceneObjectGroup>();
        private bool m_adjustClouds;
        private bool m_allowPersistentEnvironmentChanges;
        private bool m_restoreCloudsOnClear;
        private IEnvironmentModule m_environmentModule;
        private RegionLightShareData m_savedEnvironment;
        private bool m_savedEnvironmentWasUnset;
        private IWindModule m_windModule;
        private string m_savedWindPlugin;
        private Dictionary<string, float> m_savedWindParams;
        private WeatherKind m_currentWeather = WeatherKind.Clear;
        private int m_stormEffectGeneration;
        private bool m_adjustWind;
        private bool m_restoreWindOnClear;
        private float m_windDirectionDegrees;
        private float m_windDirectionVarianceDegrees;
        private float m_rainWindStrength;
        private float m_stormWindStrength;
        private float m_snowWindStrength;
        private float m_blizzardWindStrength;
        private bool m_avoidCoveredAreas;
        private float m_coverProbeHeight;
        private int m_coverProbeGrid;
        private float m_minOpenSkyFraction;
        private bool m_suppressAroundCoveredAvatars;
        private bool m_coverIncludesPhantomPrims;
        private int m_coverMaxHits;
        private bool m_useExclusionVolumes;
        private string m_exclusionObjectName;
        private int m_exclusionRefreshSeconds;
        private bool m_cleanupGeneratedObjectsOnStartup;
        private DateTime m_nextExclusionRefreshUtc;
        private readonly List<ExclusionVolume> m_exclusionVolumes = new List<ExclusionVolume>();
        private bool m_lightningEnabled;
        private int m_lightningMinDelayMS;
        private int m_lightningMaxDelayMS;
        private bool m_thunderEnabled;
        private UUID m_thunderSound = UUID.Zero;
        private float m_thunderVolume;

        // Safety net for lightning flashes: each flash's own delete is scheduled via
        // Util.FireAndForget(..., dotimeout: false), which is exempt from the thread-pool
        // watchdog's usual timeout recovery. If that delete thread ever fails to run (or the
        // scene it targets is gone), the flash would otherwise sit rezzed forever. This
        // dictionary tracks every currently-rezzed flash so a periodic sweep can force-remove
        // any that outlive their expected ~1 second lifetime.
        private readonly ConcurrentDictionary<UUID, DateTime> m_activeLightningFlashes = new ConcurrentDictionary<UUID, DateTime>();
        private static readonly TimeSpan LightningStuckAge = TimeSpan.FromSeconds(5);
        private const int LightningSweepIntervalMS = 3000;
        private Timer m_lightningSweepTimer;
        private int m_lightningSweepBusy;

        // Aurora is deliberately independent of the WeatherKind cycle - a real
        // aurora can happen on a clear night regardless of rain/snow/storm
        // state, so it's its own timer/emitter rather than another weather
        // kind. Server-side equivalent of a client-rendered aurora shader
        // (e.g. AyaneStorm's asaurora.cpp): same sun-elevation daylight-fade
        // concept, reimplemented here against a real particle emitter since
        // there's no way to push a custom shader to an arbitrary viewer -
        // this renders identically on any OpenSim-compatible client.
        private bool m_auroraEnabled;
        private float m_auroraIntensity;
        private float m_auroraCoverage;
        private float m_auroraSunFadeAngle;
        private float m_auroraHeight;
        private int m_auroraUpdateSeconds;
        private UUID m_auroraTexture = Util.BLANK_TEXTURE_UUID;
        private Vector4 m_auroraLowColor = new Vector4(0.15f, 0.85f, 0.45f, 0.55f);
        private Vector4 m_auroraHighColor = new Vector4(0.25f, 0.35f, 0.95f, 0.35f);
        private Timer m_auroraTimer;
        private int m_auroraBusy;
        private readonly List<SceneObjectGroup> m_auroraEmitters = new List<SceneObjectGroup>();
        private bool m_autoCycleEnabled;
        private float m_autoCycleHours;
        private int m_autoCycleStartupDelaySeconds;
        private bool m_autoCycleChangeOnStartup;
        private Timer m_autoCycleTimer;
        private Timer m_autoCycleWarningTimer;
        private int m_autoCycleBusy;
        private long m_nextAutoCycleTicks;
        private WeatherKind m_pendingAutoCycleWeather;
        private bool m_hasPendingAutoCycleWeather;
        private int m_autoCycleForecastWarningMinutes;
        private string m_autoCycleForecastWarningMessage;
        private bool m_sendWeatherIMOnEntry;
        private int m_weatherIMDelaySeconds;
        private string m_weatherIMMessage;
        private readonly Dictionary<WeatherKind, EnvironmentProfile> m_environmentProfiles = new Dictionary<WeatherKind, EnvironmentProfile>();
        private bool m_surfaceEffectsEnabled;
        private bool m_puddlesEnabled;
        private bool m_snowAccumulationEnabled;
        private UUID m_puddleTexture = Util.BLANK_TEXTURE_UUID;
        private UUID m_snowSurfaceTexture = Util.BLANK_TEXTURE_UUID;
        private float m_temperatureC;
        private float m_clearTemperatureC;
        private float m_sunnyTemperatureC;
        private float m_rainTemperatureC;
        private float m_stormTemperatureC;
        private float m_snowTemperatureC;
        private float m_blizzardTemperatureC;
        private float m_temperatureVarianceC;
        private bool m_announceWeatherInChat;
        // Machine-readable weather broadcast for independent in-world FX
        // objects (fireplaces, seasonal clothing, umbrellas) that aren't part
        // of this module - a plain region-wide chat message on a fixed
        // channel, same shape residents already used before this module
        // existed ("WEATHER|<kind>" on a llListen'd channel). Deliberately
        // separate from m_announceWeatherInChat above, which is a
        // human-readable report sent directly to avatars, not scripts.
        private bool m_broadcastWeatherToScripts;
        private int m_weatherBroadcastChannel;

        // Optional alternative to the plain memoryless random pick below:
        // a simulated barometric pressure that drifts toward an
        // occasionally-re-rolled target once per auto-cycle tick, with the
        // resulting weather chosen by which severity band the pressure
        // currently sits in. Gives weather a real trend across successive
        // auto-cycle picks (a storm is more likely to ease into rain/clear
        // than jump straight back to blizzard) instead of every tick being
        // an independent dice roll. Off by default - "Random" preserves the
        // existing, simpler, more predictable behavior for grid owners who
        // rely on it.
        private bool m_autoCyclePressureDriven;
        private float m_simulatedPressureHPa = 1013.25f;
        private float m_simulatedPressureTargetHPa = 1013.25f;
        private float m_freezingPointC;
        private float m_wetnessLevel;
        private float m_snowLevel;
        private float m_rainWetnessPerHour;
        private float m_stormWetnessPerHour;
        private float m_snowAccumulationPerHour;
        private float m_clearDryingPerHour;
        private float m_sunnyDryingPerHour;
        private float m_clearSnowMeltPerHour;
        private float m_sunnySnowMeltPerHour;
        private float m_rainSnowMeltPerHour;
        private float m_puddleStartLevel;
        private float m_snowPatchStartLevel;
        private float m_surfacePatchSpacingMeters;
        private float m_surfaceRadiusMeters;
        private int m_maxSurfacePatches;
        private float m_maxSurfaceSlopeDegrees;
        private float m_puddleLowPointToleranceMeters;
        private int m_surfaceUpdateSeconds;
        private Timer m_surfaceTimer;
        private int m_surfaceBusy;
        private DateTime m_lastSurfaceUpdateUtc;
        private readonly Dictionary<long, SurfacePatch> m_surfacePatches = new Dictionary<long, SurfacePatch>();

        public string Name { get { return "Weather Module"; } }

        public Type ReplaceableInterface { get { return null; } }

        public void Initialise(IConfigSource source)
        {
            IConfig config = source.Configs["Weather"];
            if (config == null)
            {
                m_enabled = false;
                m_log.Info("[WEATHER]: No [Weather] configuration found; module remains disabled.");
                return;
            }

            m_enabled = config.GetBoolean("Enabled", false);
            if (!m_enabled)
            {
                m_log.Info("[WEATHER]: Module disabled by [Weather] Enabled=false.");
                return;
            }

            m_commandChannel = config.GetInt("CommandChannel", 89);
            if (m_commandChannel == 0)
            {
                m_log.Warn("[WEATHER]: CommandChannel=0 would expose weather commands in public chat; using channel 89 instead.");
                m_commandChannel = 89;
            }

            m_estateManagerOnly = config.GetBoolean("EstateManagerOnly", true);
            m_coverageMode = ParseCoverageMode(config.GetString("CoverageMode", "Region"));
            m_emitterGrid = Clamp(config.GetInt("EmitterGrid", 8), 0, 128);
            m_emitterSpacingMeters = Clamp(config.GetFloat("EmitterSpacingMeters", 24f), 6f, 512f);
            m_maxEmitters = Clamp(config.GetInt("MaxEmitters", 384), 1, 16384);
            m_activeAreaRadiusMeters = Clamp(config.GetFloat("ActiveAreaRadiusMeters", 96f), 16f, 1024f);
            m_activeAreaRefreshSeconds = Clamp(config.GetInt("ActiveAreaRefreshSeconds", 3), 1, 300);
            m_wanderingBatchSize = Clamp(config.GetInt("WanderingBatchSize", 40), 1, 4096);
            m_wanderingRefreshSeconds = Clamp(config.GetInt("WanderingRefreshSeconds", 20), 2, 3600);
            m_wanderingChurnFraction = Clamp(config.GetFloat("WanderingChurnFraction", 0.25f), 0.02f, 1f);
            m_emitterRadiusScale = Clamp(config.GetFloat("EmitterRadiusScale", 0.62f), 0.1f, 1.25f);
            // Meters above TerrainFloor (max of water height and local
            // ground - see TerrainFloor), not meters above local dirt.
            // Raised from 18f so weather clears real multi-story buildings
            // sim-wide instead of only clearing bare terrain.
            m_emitterHeight = Clamp(config.GetFloat("EmitterHeight", 80f), 4f, 4096f);
            m_intensity = Clamp(config.GetFloat("Intensity", 1f), 0.1f, 20f);
            m_rainTexture = ReadTexture(config, "RainTexture", Util.BLANK_TEXTURE_UUID);
            m_stormTexture = ReadTexture(config, "StormTexture", m_rainTexture);
            m_snowTexture = ReadTexture(config, "SnowTexture", Util.BLANK_TEXTURE_UUID);
            m_blizzardTexture = ReadTexture(config, "BlizzardTexture", m_snowTexture);
            m_lightningTexture = ReadTexture(config, "LightningTexture", Util.BLANK_TEXTURE_UUID);

            m_adjustClouds = config.GetBoolean("AdjustEnvironment", config.GetBoolean("AdjustClouds", false));
            m_allowPersistentEnvironmentChanges = config.GetBoolean("AllowPersistentEnvironmentChanges", false);
            m_restoreCloudsOnClear = config.GetBoolean("RestoreCloudsOnClear", true);
            if (m_adjustClouds && !m_allowPersistentEnvironmentChanges)
            {
                m_adjustClouds = false;
                m_log.Warn(
                    "[WEATHER]: AdjustEnvironment=true ignored because AllowPersistentEnvironmentChanges is not true. "
                    + "OpenSim stores LightShare/EEP region environment changes; enable the acknowledgement only after reading the module documentation.");
            }

            m_adjustWind = config.GetBoolean("AdjustWind", false);
            m_restoreWindOnClear = config.GetBoolean("RestoreWindOnClear", true);
            m_windDirectionDegrees = config.GetFloat("WindDirectionDegrees", 70f);
            m_windDirectionVarianceDegrees = Math.Max(0f, config.GetFloat("WindDirectionVarianceDegrees", 18f));
            m_rainWindStrength = Math.Max(0f, config.GetFloat("RainWindStrength", 0.45f));
            m_stormWindStrength = Math.Max(0f, config.GetFloat("StormWindStrength", 1.35f));
            m_snowWindStrength = Math.Max(0f, config.GetFloat("SnowWindStrength", 0.22f));
            m_blizzardWindStrength = Math.Max(0f, config.GetFloat("BlizzardWindStrength", 1.55f));

            m_avoidCoveredAreas = config.GetBoolean("AvoidCoveredAreas", true);
            m_coverProbeHeight = Clamp(config.GetFloat("CoverProbeHeight", 256f), 8f, 4096f);
            m_coverProbeGrid = Clamp(config.GetInt("CoverProbeGrid", 3), 1, 7);
            if ((m_coverProbeGrid & 1) == 0)
                m_coverProbeGrid++;
            m_minOpenSkyFraction = Clamp(config.GetFloat("MinimumOpenSkyFraction", 0.67f), 0f, 1f);
            m_suppressAroundCoveredAvatars = config.GetBoolean("SuppressAroundCoveredAvatars", true);
            m_coverIncludesPhantomPrims = config.GetBoolean("CoverIncludesPhantomPrims", false);
            m_coverMaxHits = Clamp(config.GetInt("CoverMaxHits", 32), 1, 128);
            m_useExclusionVolumes = config.GetBoolean("UseExclusionVolumes", true);
            m_exclusionObjectName = config.GetString("ExclusionObjectName", "Weather Exclusion").Trim();
            m_exclusionRefreshSeconds = Clamp(config.GetInt("ExclusionRefreshSeconds", 30), 5, 3600);
            m_cleanupGeneratedObjectsOnStartup = config.GetBoolean("CleanupGeneratedObjectsOnStartup", true);
            if (string.IsNullOrEmpty(m_exclusionObjectName))
                m_useExclusionVolumes = false;

            m_lightningEnabled = config.GetBoolean("LightningEnabled", true);
            m_lightningMinDelayMS = Clamp(config.GetInt("LightningMinDelayMS", 7000), 1000, 3600000);
            m_lightningMaxDelayMS = Clamp(config.GetInt("LightningMaxDelayMS", 18000), m_lightningMinDelayMS, 3600000);

            m_thunderEnabled = config.GetBoolean("ThunderEnabled", false);
            m_thunderVolume = Clamp(config.GetFloat("ThunderVolume", 1f), 0f, 1f);
            m_thunderSound = UUID.Zero;
            string thunderSound = config.GetString("ThunderSound", string.Empty).Trim();
            if (!string.IsNullOrEmpty(thunderSound) && !UUID.TryParse(thunderSound, out m_thunderSound))
            {
                m_thunderSound = UUID.Zero;
                m_log.WarnFormat("[WEATHER]: ThunderSound '{0}' is not a valid UUID; thunder audio disabled.", thunderSound);
            }
            else if (m_thunderEnabled && m_thunderSound == UUID.Zero)
            {
                m_log.Info("[WEATHER]: ThunderEnabled=true but ThunderSound is empty; visual lightning will continue without thunder audio.");
            }

            m_auroraEnabled = config.GetBoolean("AuroraEnabled", false);
            m_auroraIntensity = Clamp(config.GetFloat("AuroraIntensity", 1f), 0f, 4f);
            m_auroraCoverage = Clamp(config.GetFloat("AuroraCoverage", 0.35f), 0f, 1f);
            // Same range/shape as AyaneStorm's ASAuroraSunFadeAngle: sun
            // elevation (degrees) where the fade-in starts, faded fully in by
            // 6 degrees further below the horizon.
            m_auroraSunFadeAngle = Clamp(config.GetFloat("AuroraSunFadeAngle", -6f), -18f, 5f);
            m_auroraHeight = Clamp(config.GetFloat("AuroraHeight", 220f), 20f, 4096f);
            m_auroraUpdateSeconds = Clamp(config.GetInt("AuroraUpdateSeconds", 30), 5, 3600);
            m_auroraTexture = ReadTexture(config, "AuroraTexture", Util.BLANK_TEXTURE_UUID);
            m_auroraLowColor = ReadVector4(config, "AuroraLowColor", m_auroraLowColor);
            m_auroraHighColor = ReadVector4(config, "AuroraHighColor", m_auroraHighColor);

            m_autoCycleEnabled = config.GetBoolean("AutoCycleEnabled", false);
            m_autoCycleHours = Clamp(config.GetFloat("AutoCycleHours", 6f), 0.01f, 596f);
            m_autoCycleStartupDelaySeconds = Clamp(config.GetInt("AutoCycleStartupDelaySeconds", 30), 1, 86400);
            m_autoCycleChangeOnStartup = config.GetBoolean("AutoCycleChangeOnStartup", false);
            ParseAutoCycleChoices(config.GetString("AutoCycleChoices", "storm,rain,snow,sunny,clear"));
            m_autoCycleForecastWarningMinutes = Clamp(config.GetInt("AutoCycleForecastWarningMinutes", 15), 0, 35790);
            m_autoCycleForecastWarningMessage = config.GetString(
                "AutoCycleForecastWarningMessage",
                "Weather forecast update: next conditions for {RegionName} are expected to shift to {NextWeather} in {TimeUntilNextForecast}.").Trim();

            if (m_autoCycleEnabled
                && m_autoCycleForecastWarningMinutes > 0
                && m_autoCycleForecastWarningMinutes * 60f >= m_autoCycleHours * 60f * 60f)
            {
                m_log.Warn(
                    "[WEATHER]: AutoCycleForecastWarningMinutes is equal to or longer than AutoCycleHours; "
                    + "forecast warnings will not be scheduled.");
            }

            m_sendWeatherIMOnEntry = config.GetBoolean("SendWeatherIMOnEntry", false);
            m_weatherIMDelaySeconds = Clamp(config.GetInt("WeatherIMDelaySeconds", 8), 0, 3600);
            m_weatherIMMessage = config.GetString(
                "WeatherIMMessage",
                "Weather forecast for {RegionName}: current conditions are {Weather}, {Temperature}C. Next forecast: {NextForecast}. Stay tuned for further regional updates.").Trim();

            m_surfaceEffectsEnabled = config.GetBoolean("SurfaceEffectsEnabled", false);
            m_puddlesEnabled = config.GetBoolean("PuddlesEnabled", true);
            m_snowAccumulationEnabled = config.GetBoolean("SnowAccumulationEnabled", true);
            m_puddleTexture = ReadTexture(config, "PuddleTexture", Util.BLANK_TEXTURE_UUID);
            m_snowSurfaceTexture = ReadTexture(config, "SnowSurfaceTexture", Util.BLANK_TEXTURE_UUID);
            m_temperatureC = Clamp(config.GetFloat("TemperatureC", 10f), -100f, 100f);
            m_clearTemperatureC = Clamp(config.GetFloat("ClearTemperatureC", m_temperatureC), -100f, 100f);
            m_sunnyTemperatureC = Clamp(config.GetFloat("SunnyTemperatureC", 22f), -100f, 100f);
            m_rainTemperatureC = Clamp(config.GetFloat("RainTemperatureC", 12f), -100f, 100f);
            m_stormTemperatureC = Clamp(config.GetFloat("StormTemperatureC", 9f), -100f, 100f);
            m_snowTemperatureC = Clamp(config.GetFloat("SnowTemperatureC", -2f), -100f, 100f);
            m_blizzardTemperatureC = Clamp(config.GetFloat("BlizzardTemperatureC", -12f), -100f, 100f);
            m_temperatureVarianceC = Clamp(config.GetFloat("TemperatureVarianceC", 3f), 0f, 50f);
            m_announceWeatherInChat = config.GetBoolean("AnnounceWeatherChangesInChat", true);
            m_broadcastWeatherToScripts = config.GetBoolean("BroadcastWeatherToScripts", true);
            m_weatherBroadcastChannel = config.GetInt("WeatherBroadcastChannel", -910088);
            m_autoCyclePressureDriven = string.Equals(
                    config.GetString("AutoCyclePacing", "Random"), "Pressure", StringComparison.OrdinalIgnoreCase);
            m_freezingPointC = Clamp(config.GetFloat("FreezingPointC", 0f), -20f, 20f);
            m_rainWetnessPerHour = Math.Max(0f, config.GetFloat("RainWetnessPerHour", 0.35f));
            m_stormWetnessPerHour = Math.Max(0f, config.GetFloat("StormWetnessPerHour", 0.75f));
            m_snowAccumulationPerHour = Math.Max(0f, config.GetFloat("SnowAccumulationPerHour", 0.3f));
            m_clearDryingPerHour = Math.Max(0f, config.GetFloat("ClearDryingPerHour", 0.08f));
            m_sunnyDryingPerHour = Math.Max(0f, config.GetFloat("SunnyDryingPerHour", 0.25f));
            m_clearSnowMeltPerHour = Math.Max(0f, config.GetFloat("ClearSnowMeltPerHour", 0.05f));
            m_sunnySnowMeltPerHour = Math.Max(0f, config.GetFloat("SunnySnowMeltPerHour", 0.22f));
            m_rainSnowMeltPerHour = Math.Max(0f, config.GetFloat("RainSnowMeltPerHour", 0.45f));
            m_puddleStartLevel = Clamp(config.GetFloat("PuddleStartLevel", 0.12f), 0f, 1f);
            m_snowPatchStartLevel = Clamp(config.GetFloat("SnowPatchStartLevel", 0.08f), 0f, 1f);
            m_surfacePatchSpacingMeters = Clamp(config.GetFloat("SurfacePatchSpacingMeters", 20f), 4f, 128f);
            m_surfaceRadiusMeters = Clamp(config.GetFloat("SurfaceRadiusMeters", 80f), 8f, 512f);
            m_maxSurfacePatches = Clamp(config.GetInt("MaxSurfacePatches", 128), 1, 4096);
            m_maxSurfaceSlopeDegrees = Clamp(config.GetFloat("MaxSurfaceSlopeDegrees", 8f), 0f, 45f);
            m_puddleLowPointToleranceMeters = Clamp(config.GetFloat("PuddleLowPointToleranceMeters", 0.08f), 0f, 2f);
            m_surfaceUpdateSeconds = Clamp(config.GetInt("SurfaceUpdateSeconds", 60), 10, 3600);

            if (m_surfaceEffectsEnabled)
            {
                if (m_puddlesEnabled && m_puddleTexture == Util.BLANK_TEXTURE_UUID)
                {
                    m_puddlesEnabled = false;
                    m_log.Warn("[WEATHER]: PuddlesEnabled=true ignored because PuddleTexture is blank. Upload an alpha puddle texture and configure its UUID.");
                }

                if (m_snowAccumulationEnabled && m_snowSurfaceTexture == Util.BLANK_TEXTURE_UUID)
                {
                    m_snowAccumulationEnabled = false;
                    m_log.Warn("[WEATHER]: SnowAccumulationEnabled=true ignored because SnowSurfaceTexture is blank. Upload a feathered snow overlay and configure its UUID.");
                }

                if (!m_puddlesEnabled && !m_snowAccumulationEnabled)
                {
                    m_surfaceEffectsEnabled = false;
                    m_log.Warn("[WEATHER]: SurfaceEffectsEnabled=true but no usable puddle or snow surface texture is configured; surface effects disabled.");
                }
            }

            if (m_rainTexture == Util.BLANK_TEXTURE_UUID)
                m_log.Warn("[WEATHER]: RainTexture is blank; rain will use viewer billboards and may look rectangular.");
            if (m_snowTexture == Util.BLANK_TEXTURE_UUID)
                m_log.Warn("[WEATHER]: SnowTexture is blank; snow will look like square billboards until a snowflake texture UUID is configured.");

            LoadEnvironmentProfiles(source);

            if (m_emitterGrid > 0)
            {
                m_log.InfoFormat(
                    "[WEATHER]: Region coverage uses an {0}x{0} emitter grid scaled to the actual region dimensions. "
                    + "Set EmitterGrid=0 to use fixed-metre EmitterSpacingMeters instead.",
                    m_emitterGrid);
            }

            if (!m_restoreCloudsOnClear && m_adjustClouds)
                m_log.Warn("[WEATHER]: RestoreCloudsOnClear=false can intentionally leave the weather environment active after clear.");
            if (!m_restoreWindOnClear && m_adjustWind)
                m_log.Warn("[WEATHER]: RestoreWindOnClear=false can intentionally leave weather wind parameters active after clear.");
        }

        public void AddRegion(Scene scene)
        {
            if (!m_enabled)
                return;

            m_scene = scene;
            m_scene.EventManager.OnChatFromClient += OnChatFromClient;
            m_scene.EventManager.OnMakeRootAgent += OnMakeRootAgent;
            m_log.InfoFormat(
                "[WEATHER]: Enabled in region {0} on channel {1}",
                scene.RegionInfo.RegionName,
                m_commandChannel);
        }

        public void RemoveRegion(Scene scene)
        {
            StopAutoCycle();
            StopActiveAreaRefresh();
            StopWanderingRefresh();
            StopSurfaceTimer();
            StopAuroraTimer();
            StopLightningSweepTimer();
            RemoveAuroraEmitters();

            Scene activeScene = m_scene;
            if (activeScene != null)
            {
                activeScene.EventManager.OnChatFromClient -= OnChatFromClient;
                activeScene.EventManager.OnMakeRootAgent -= OnMakeRootAgent;
            }

            lock (m_weatherChangeSync)
            {
                ClearWeather(false, true, true);
                m_scene = null;
                m_environmentModule = null;
                m_windModule = null;
            }
        }

        public void RegionLoaded(Scene scene)
        {
            if (!m_enabled)
                return;

            m_environmentModule = scene.RequestModuleInterface<IEnvironmentModule>();
            if (m_adjustClouds && m_environmentModule == null)
            {
                m_log.WarnFormat("[WEATHER]: Cloud changes disabled in {0}; EnvironmentModule is not available.", scene.RegionInfo.RegionName);
            }
            else if (m_adjustClouds)
            {
                m_log.WarnFormat(
                    "[WEATHER]: Cloud adjustment is enabled in {0}. OpenSim persists these region environment changes; "
                    + "a process crash can prevent automatic restoration.",
                    scene.RegionInfo.RegionName);
            }

            m_windModule = scene.RequestModuleInterface<IWindModule>();
            if (m_adjustWind && m_windModule == null)
            {
                m_log.WarnFormat("[WEATHER]: Region wind changes disabled in {0}; WindModule is not available.", scene.RegionInfo.RegionName);
            }
            else if (m_adjustWind
                && m_windModule.WindActiveModelPluginName != "SimpleRandomWind"
                && m_windModule.WindActiveModelPluginName != "ConfigurableWind")
            {
                m_log.WarnFormat(
                    "[WEATHER]: Wind plugin '{0}' in {1} is not supported; weather will not alter region wind.",
                    m_windModule.WindActiveModelPluginName,
                    scene.RegionInfo.RegionName);
            }

            if (m_cleanupGeneratedObjectsOnStartup)
                CleanupGeneratedObjects();

            RefreshExclusionVolumes(true);
            StartAutoCycle();
            StartSurfaceTimer();
            StartAuroraTimer();
            StartLightningSweepTimer();
        }

        public void Close()
        {
            StopAutoCycle();
            StopActiveAreaRefresh();
            StopWanderingRefresh();
            StopSurfaceTimer();
            StopAuroraTimer();
            StopLightningSweepTimer();
            RemoveAuroraEmitters();

            lock (m_weatherChangeSync)
            {
                ClearWeather(false, true, true);
                m_scene = null;
                m_environmentModule = null;
                m_windModule = null;
            }
        }

        private void OnMakeRootAgent(ScenePresence sp)
        {
            if (sp == null || sp.IsDeleted || sp.IsNPC || sp.IsChildAgent)
                return;

            if (m_coverageMode == CoverageMode.ActiveArea && IsPrecipitationWeather(CurrentWeather()))
                QueueActiveAreaRefresh();

            if (m_surfaceEffectsEnabled)
                QueueSurfaceUpdate(true);

            if (!m_sendWeatherIMOnEntry)
                return;

            UUID agentID = sp.UUID;
            Util.FireAndForget(
                o =>
                {
                    if (m_weatherIMDelaySeconds > 0)
                        Thread.Sleep(m_weatherIMDelaySeconds * 1000);

                    SendWeatherIM(agentID);
                },
                null,
                "WeatherModule.EntryIM",
                false);
        }

        private void OnChatFromClient(object sender, OSChatMessage chat)
        {
            if (chat == null || chat.Sender == null || chat.Channel != m_commandChannel)
                return;

            Scene scene = m_scene;
            if (scene == null)
                return;

            string request = chat.Message == null ? string.Empty : chat.Message.Trim();
            if (!IsWeatherCommand(request))
                return;

            IClientAPI client = chat.Sender;
            if (m_estateManagerOnly && !scene.Permissions.IsEstateManager(client.AgentId))
            {
                SendReply(client, "Only estate managers can change weather here.");
                return;
            }

            if (IsStatusCommand(request))
            {
                SendStatus(client);
                return;
            }

            if (!TryResolveWeather(request, out WeatherKind weather))
            {
                SendReply(client, "Use weather rain, weather storm, weather snow, weather blizzard, weather sunny, weather clear, or weather status.");
                return;
            }

            if (weather == WeatherKind.Clear)
            {
                // Explicit "weather clear"/"weather stop" from a person means
                // hands off, not "clear is this cycle's pick" - stop the auto
                // cycle timer entirely rather than letting it silently
                // override this a few minutes/hours later (previously it
                // called ScheduleNextAutoCycle() unconditionally in its
                // finally block regardless of how Clear was reached, so an
                // explicit clear never actually stayed clear). Any other
                // explicit weather command below restarts the timer, since
                // issuing one means the person is actively back in control.
                ClearWeather(true, true);
                UpdateTemperatureForWeather(WeatherKind.Clear);
                AnnounceWeatherChange(WeatherKind.Clear);
                BroadcastWeatherToScripts(WeatherKind.Clear);
                StopAutoCycle();
                SendReply(client, m_autoCycleEnabled
                        ? "Clear. Auto cycle stopped - use any weather command (e.g. \"weather storm\") to resume it."
                        : "Clear.");
                return;
            }

            if (ApplyWeather(weather, client.AgentId))
            {
                StartAutoCycle();
                SendReply(client, string.Format("{0} started.", WeatherName(weather)));
            }
            else
                SendReply(client, "Could not create emitters.");
        }

        private bool ApplyWeather(WeatherKind weather, UUID ownerId)
        {
            lock (m_weatherChangeSync)
            {
                ClearWeather(false, false);

                Scene scene = m_scene;
                if (scene == null)
                    return false;

                List<SceneObjectGroup> created = new List<SceneObjectGroup>();

                try
                {
                    m_weatherOwnerId = ownerId;
                    lock (m_sync)
                        m_currentWeather = weather;
                    UpdateTemperatureForWeather(weather);

                    // Sky/wind changes are near-instant; emitter creation can take
                    // a noticeable moment on large regions. Apply the environment
                    // first so the sky visibly changes before precipitation
                    // appears, not after.
                    ApplyClouds(weather);
                    ApplyWind(weather);

                    if (IsPrecipitationWeather(weather))
                    {
                        if (m_coverageMode == CoverageMode.ActiveArea)
                        {
                            RefreshActiveAreaEmittersInternal();
                            StartActiveAreaRefresh();
                        }
                        else if (m_coverageMode == CoverageMode.Wandering)
                        {
                            created = CreateWanderingEmitters(weather, m_wanderingBatchSize);
                            if (created.Count == 0)
                                throw new InvalidOperationException("No uncovered emitter locations were available.");

                            lock (m_sync)
                                m_emitters.AddRange(created);

                            StartWanderingRefresh();
                        }
                        else
                        {
                            created = CreateRegionEmitters(ownerId, weather);
                            if (created.Count == 0)
                                throw new InvalidOperationException("No uncovered emitter locations were available.");

                            lock (m_sync)
                                m_emitters.AddRange(created);
                        }
                    }

                    BoostSurfaceForWeather(weather);
                    if (weather == WeatherKind.Storm)
                        StartStormEffects(ownerId);

                    int emitterCount;
                    lock (m_sync)
                        emitterCount = m_emitters.Count;

                    m_log.InfoFormat(
                        "[WEATHER]: Started {0} in {1} with {2} emitters using {3} coverage",
                        WeatherName(weather),
                        scene.RegionInfo.RegionName,
                        emitterCount,
                        CoverageModeName(m_coverageMode));

                    AnnounceWeatherChange(weather);
                    BroadcastWeatherToScripts(weather);
                    return true;
                }
                catch (Exception e)
                {
                    StopStormEffects();
                    StopActiveAreaRefresh();
                    StopWanderingRefresh();

                    List<SceneObjectGroup> rollbackEmitters;
                    lock (m_sync)
                    {
                        rollbackEmitters = new List<SceneObjectGroup>(m_emitters);
                        m_emitters.Clear();
                        m_activeEmitterCells.Clear();
                        m_currentWeather = WeatherKind.Clear;
                    }

                    DeleteEmitters(rollbackEmitters);
                    RestoreClouds(true);
                    RestoreWind(true);

                    string regionName = m_scene == null ? "unknown region" : m_scene.RegionInfo.RegionName;
                    m_log.WarnFormat(
                        "[WEATHER]: Could not start {0} in {1}; partial changes were rolled back: {2}",
                        WeatherName(weather),
                        regionName,
                        e.Message);
                    return false;
                }
            }
        }

        private List<SceneObjectGroup> CreateRegionEmitters(UUID ownerId, WeatherKind weather)
        {
            Scene scene = m_scene;
            List<SceneObjectGroup> created = new List<SceneObjectGroup>();
            if (scene == null)
                return created;

            int sizeX = Math.Max(1, (int)scene.RegionInfo.RegionSizeX);
            int sizeY = Math.Max(1, (int)scene.RegionInfo.RegionSizeY);
            GetEmitterLayout(sizeX, sizeY, out int countX, out int countY, out float spacingX, out float spacingY);
            float radius = Math.Min(MaxParticleBurstRadius, Math.Max(spacingX, spacingY) * m_emitterRadiusScale);

            for (int x = 0; x < countX; x++)
            {
                for (int y = 0; y < countY; y++)
                {
                    float posX = JitteredCellPosition(x, countX, spacingX, sizeX);
                    float posY = JitteredCellPosition(y, countY, spacingY, sizeY);
                    Vector3 position = new Vector3(posX, posY, EmitterBaseHeight(posX, posY));
                    float openSky = GetOpenSkyFraction(posX, posY, spacingX * 0.45f, spacingY * 0.45f, position.Z);
                    if (openSky < m_minOpenSkyFraction)
                        continue;

                    SceneObjectGroup emitter = CreateEmitter(ownerId, weather, position, radius * (float)Math.Sqrt(Math.Max(0.15f, openSky)));
                    if (!scene.AddNewSceneObject(emitter, false))
                        throw new InvalidOperationException("OpenSim rejected a weather emitter.");

                    emitter.RootPart.SendFullUpdateToAllClients();
                    emitter.ScheduleGroupForUpdate(PrimUpdateFlags.FullUpdatewithAnimMatOvr);
                    created.Add(emitter);
                }
            }

            return created;
        }

        private void GetEmitterLayout(int sizeX, int sizeY, out int countX, out int countY, out float spacingX, out float spacingY)
        {
            if (m_emitterGrid > 0)
            {
                countX = m_emitterGrid;
                countY = m_emitterGrid;
            }
            else
            {
                countX = Math.Max(1, (int)Math.Ceiling(sizeX / m_emitterSpacingMeters));
                countY = Math.Max(1, (int)Math.Ceiling(sizeY / m_emitterSpacingMeters));
            }

            int requestedCountX = countX;
            int requestedCountY = countY;
            long requested = (long)countX * countY;
            if (requested > m_maxEmitters)
            {
                double scale = Math.Sqrt(m_maxEmitters / (double)requested);
                countX = Math.Max(1, (int)Math.Floor(countX * scale));
                countY = Math.Max(1, (int)Math.Floor(countY * scale));

                while ((long)countX * countY > m_maxEmitters)
                {
                    if (countX >= countY && countX > 1)
                        countX--;
                    else if (countY > 1)
                        countY--;
                    else
                        break;
                }

                while ((long)(countX + 1) * countY <= m_maxEmitters
                    && sizeX / (double)countX > sizeY / (double)countY)
                {
                    countX++;
                }

                while ((long)countX * (countY + 1) <= m_maxEmitters
                    && sizeY / (double)countY > sizeX / (double)countX)
                {
                    countY++;
                }

                m_log.WarnFormat(
                    "[WEATHER]: Requested emitter layout {0}x{1} ({2} objects) for a {3}x{4} region exceeds MaxEmitters={5}; "
                    + "using {6}x{7}. Increase MaxEmitters only after testing simulator and viewer load.",
                    requestedCountX,
                    requestedCountY,
                    requested,
                    sizeX,
                    sizeY,
                    m_maxEmitters,
                    countX,
                    countY);
            }

            spacingX = sizeX / (float)countX;
            spacingY = sizeY / (float)countY;
        }

        private void StartActiveAreaRefresh()
        {
            if (m_coverageMode != CoverageMode.ActiveArea || !IsPrecipitationWeather(CurrentWeather()) || m_scene == null)
                return;

            StopActiveAreaRefresh();
            int period = m_activeAreaRefreshSeconds * 1000;
            m_activeAreaTimer = new Timer(ActiveAreaTimerElapsed, null, period, period);
        }

        private void StopActiveAreaRefresh()
        {
            Timer timer = Interlocked.Exchange(ref m_activeAreaTimer, null);
            if (timer != null)
                timer.Dispose();
        }

        private void QueueActiveAreaRefresh()
        {
            Timer timer = m_activeAreaTimer;
            if (timer != null)
                timer.Change(0, m_activeAreaRefreshSeconds * 1000);
        }

        private void ActiveAreaTimerElapsed(object state)
        {
            if (Interlocked.Exchange(ref m_activeAreaBusy, 1) != 0)
                return;

            try
            {
                lock (m_weatherChangeSync)
                    RefreshActiveAreaEmittersInternal();
            }
            catch (Exception e)
            {
                m_log.WarnFormat("[WEATHER]: Active-area emitter refresh failed: {0}", e.Message);
            }
            finally
            {
                Interlocked.Exchange(ref m_activeAreaBusy, 0);
            }
        }

        private void RefreshActiveAreaEmittersInternal()
        {
            Scene scene = m_scene;
            WeatherKind weather = CurrentWeather();
            if (scene == null || m_coverageMode != CoverageMode.ActiveArea || !IsPrecipitationWeather(weather))
                return;

            int sizeX = Math.Max(1, (int)scene.RegionInfo.RegionSizeX);
            int sizeY = Math.Max(1, (int)scene.RegionInfo.RegionSizeY);
            float spacing = m_emitterSpacingMeters;
            float radius = Math.Min(MaxParticleBurstRadius, spacing * m_emitterRadiusScale);
            HashSet<long> needed = new HashSet<long>();

            scene.ForEachRootScenePresence(sp =>
            {
                if (sp == null || sp.IsDeleted || sp.IsNPC || sp.IsChildAgent)
                    return;

                Vector3 avatarPosition = sp.AbsolutePosition;
                float avatarGround = scene.GetGroundHeight(avatarPosition.X, avatarPosition.Y);
                if (m_suppressAroundCoveredAvatars
                    && IsCoveredFromSky(avatarPosition.X, avatarPosition.Y, avatarGround, Math.Max(avatarPosition.Z, TerrainFloor(avatarPosition.X, avatarPosition.Y) + m_emitterHeight)))
                    return;

                int minCellX = Math.Max(0, (int)Math.Floor((avatarPosition.X - m_activeAreaRadiusMeters) / spacing));
                int maxCellX = Math.Min((int)Math.Ceiling(sizeX / spacing) - 1, (int)Math.Floor((avatarPosition.X + m_activeAreaRadiusMeters) / spacing));
                int minCellY = Math.Max(0, (int)Math.Floor((avatarPosition.Y - m_activeAreaRadiusMeters) / spacing));
                int maxCellY = Math.Min((int)Math.Ceiling(sizeY / spacing) - 1, (int)Math.Floor((avatarPosition.Y + m_activeAreaRadiusMeters) / spacing));

                for (int cellX = minCellX; cellX <= maxCellX && needed.Count < m_maxEmitters; cellX++)
                {
                    for (int cellY = minCellY; cellY <= maxCellY && needed.Count < m_maxEmitters; cellY++)
                    {
                        float centerX = Math.Min(sizeX - 1f, (cellX + 0.5f) * spacing);
                        float centerY = Math.Min(sizeY - 1f, (cellY + 0.5f) * spacing);
                        float dx = centerX - avatarPosition.X;
                        float dy = centerY - avatarPosition.Y;
                        if (dx * dx + dy * dy > m_activeAreaRadiusMeters * m_activeAreaRadiusMeters)
                            continue;

                        needed.Add(CellKey(cellX, cellY));
                    }
                }
            });

            List<SceneObjectGroup> delete = new List<SceneObjectGroup>();
            lock (m_sync)
            {
                List<long> obsolete = new List<long>();
                foreach (KeyValuePair<long, SceneObjectGroup> pair in m_activeEmitterCells)
                {
                    if (!needed.Contains(pair.Key))
                    {
                        obsolete.Add(pair.Key);
                        delete.Add(pair.Value);
                        m_emitters.Remove(pair.Value);
                    }
                }

                foreach (long key in obsolete)
                    m_activeEmitterCells.Remove(key);
            }
            DeleteEmitters(delete);

            foreach (long key in needed)
            {
                lock (m_sync)
                {
                    if (m_activeEmitterCells.ContainsKey(key))
                        continue;
                }

                DecodeCellKey(key, out int cellX, out int cellY);
                float posX = Math.Min(sizeX - 1f, (cellX + 0.5f) * spacing);
                float posY = Math.Min(sizeY - 1f, (cellY + 0.5f) * spacing);
                Vector3 position = new Vector3(posX, posY, EmitterBaseHeight(posX, posY));
                float openSky = GetOpenSkyFraction(posX, posY, spacing * 0.45f, spacing * 0.45f, position.Z);
                if (openSky < m_minOpenSkyFraction)
                    continue;

                SceneObjectGroup emitter = CreateEmitter(m_weatherOwnerId, weather, position, radius * (float)Math.Sqrt(Math.Max(0.15f, openSky)));
                if (!scene.AddNewSceneObject(emitter, false))
                    continue;

                emitter.RootPart.SendFullUpdateToAllClients();
                emitter.ScheduleGroupForUpdate(PrimUpdateFlags.FullUpdatewithAnimMatOvr);
                lock (m_sync)
                {
                    m_activeEmitterCells[key] = emitter;
                    m_emitters.Add(emitter);
                }
            }
        }

        private void StartWanderingRefresh()
        {
            if (m_coverageMode != CoverageMode.Wandering || !IsPrecipitationWeather(CurrentWeather()) || m_scene == null)
                return;

            StopWanderingRefresh();
            int period = m_wanderingRefreshSeconds * 1000;
            m_wanderingTimer = new Timer(WanderingTimerElapsed, null, period, period);
        }

        private void StopWanderingRefresh()
        {
            Timer timer = Interlocked.Exchange(ref m_wanderingTimer, null);
            if (timer != null)
                timer.Dispose();
        }

        private void WanderingTimerElapsed(object state)
        {
            if (Interlocked.Exchange(ref m_wanderingBusy, 1) != 0)
                return;

            try
            {
                lock (m_weatherChangeSync)
                    RefreshWanderingEmittersInternal();
            }
            catch (Exception e)
            {
                m_log.WarnFormat("[WEATHER]: Wandering emitter refresh failed: {0}", e.Message);
            }
            finally
            {
                Interlocked.Exchange(ref m_wanderingBusy, 0);
            }
        }

        // Retires the oldest fraction of the pool and respawns replacements at new
        // random positions, so weather keeps drifting/patchy instead of settling
        // into a static grid - and the pool size stays independent of region size,
        // avoiding the cost of covering a whole var region up front.
        private void RefreshWanderingEmittersInternal()
        {
            Scene scene = m_scene;
            WeatherKind weather = CurrentWeather();
            if (scene == null || m_coverageMode != CoverageMode.Wandering || !IsPrecipitationWeather(weather))
                return;

            List<SceneObjectGroup> retire;
            int deficit;
            lock (m_sync)
            {
                int churnCount = Math.Min(m_emitters.Count, Math.Max(1, (int)Math.Ceiling(m_emitters.Count * m_wanderingChurnFraction)));
                retire = new List<SceneObjectGroup>(churnCount);
                for (int i = 0; i < churnCount; i++)
                {
                    retire.Add(m_emitters[0]);
                    m_emitters.RemoveAt(0);
                }

                deficit = m_wanderingBatchSize - m_emitters.Count;
            }

            DeleteEmitters(retire);

            List<SceneObjectGroup> created = CreateWanderingEmitters(weather, Math.Max(0, deficit));
            lock (m_sync)
                m_emitters.AddRange(created);

            m_log.DebugFormat(
                "[WEATHER]: Wandering refresh in {0}: retired {1}, spawned {2}, pool={3}",
                scene.RegionInfo.RegionName,
                retire.Count,
                created.Count,
                m_emitters.Count);
        }

        private List<SceneObjectGroup> CreateWanderingEmitters(WeatherKind weather, int count)
        {
            List<SceneObjectGroup> created = new List<SceneObjectGroup>(Math.Max(0, count));
            Scene scene = m_scene;
            if (scene == null || count <= 0)
                return created;

            int sizeX = Math.Max(1, (int)scene.RegionInfo.RegionSizeX);
            int sizeY = Math.Max(1, (int)scene.RegionInfo.RegionSizeY);
            float radius = Math.Min(MaxParticleBurstRadius, m_emitterSpacingMeters * m_emitterRadiusScale);
            float probeHalfExtent = m_emitterSpacingMeters * 0.45f;

            for (int i = 0; i < count; i++)
            {
                SceneObjectGroup emitter = null;

                for (int attempt = 0; attempt < 6 && emitter == null; attempt++)
                {
                    float posX = RandomRange(1f, sizeX - 1f);
                    float posY = RandomRange(1f, sizeY - 1f);
                    Vector3 position = new Vector3(posX, posY, EmitterBaseHeight(posX, posY));
                    float openSky = GetOpenSkyFraction(posX, posY, probeHalfExtent, probeHalfExtent, position.Z);
                    if (openSky < m_minOpenSkyFraction)
                        continue;

                    SceneObjectGroup candidate = CreateEmitter(
                        m_weatherOwnerId, weather, position, radius * (float)Math.Sqrt(Math.Max(0.15f, openSky)));
                    if (!scene.AddNewSceneObject(candidate, false))
                        continue;

                    candidate.RootPart.SendFullUpdateToAllClients();
                    candidate.ScheduleGroupForUpdate(PrimUpdateFlags.FullUpdatewithAnimMatOvr);
                    emitter = candidate;
                }

                if (emitter != null)
                    created.Add(emitter);
            }

            return created;
        }

        private static long CellKey(int x, int y)
        {
            return ((long)x << 32) | (uint)y;
        }

        private static void DecodeCellKey(long key, out int x, out int y)
        {
            x = (int)(key >> 32);
            y = (int)(key & 0xffffffffL);
        }

        private void StartAutoCycle()
        {
            if (!m_autoCycleEnabled || m_scene == null)
                return;

            StopAutoCycle();

            int dueTime = m_autoCycleChangeOnStartup
                ? m_autoCycleStartupDelaySeconds * 1000
                : AutoCycleIntervalMS();

            m_autoCycleTimer = new Timer(AutoCycleTimerElapsed, null, Timeout.Infinite, Timeout.Infinite);
            m_autoCycleWarningTimer = new Timer(AutoCycleForecastWarningElapsed, null, Timeout.Infinite, Timeout.Infinite);
            ScheduleAutoCycle(dueTime);

            m_log.InfoFormat(
                "[WEATHER]: Auto cycle enabled in {0}; choices={1}, interval={2:0.##} hours",
                m_scene.RegionInfo.RegionName,
                AutoCycleChoiceNames(),
                m_autoCycleHours);
        }

        private void StopAutoCycle()
        {
            Timer timer = m_autoCycleTimer;
            m_autoCycleTimer = null;
            Timer warningTimer = m_autoCycleWarningTimer;
            m_autoCycleWarningTimer = null;

            if (timer != null)
                timer.Dispose();
            if (warningTimer != null)
                warningTimer.Dispose();

            Interlocked.Exchange(ref m_autoCycleBusy, 0);
            m_nextAutoCycleTicks = 0;
            m_hasPendingAutoCycleWeather = false;
        }

        private void AutoCycleTimerElapsed(object state)
        {
            if (Interlocked.Exchange(ref m_autoCycleBusy, 1) != 0)
                return;

            try
            {
                Scene scene = m_scene;
                if (scene == null)
                    return;

                WeatherKind weather;
                lock (m_sync)
                {
                    weather = m_hasPendingAutoCycleWeather ? m_pendingAutoCycleWeather : PickAutoCycleWeather();
                    m_hasPendingAutoCycleWeather = false;
                }

                if (weather == WeatherKind.Clear)
                {
                    ClearWeather(true, true);
                    UpdateTemperatureForWeather(WeatherKind.Clear);
                    AnnounceWeatherChange(WeatherKind.Clear);
                    BroadcastWeatherToScripts(WeatherKind.Clear);
                    m_log.InfoFormat("[WEATHER]: Auto cycle selected clear in {0}", scene.RegionInfo.RegionName);
                }
                else if (ApplyWeather(weather, UUID.Zero))
                {
                    m_log.InfoFormat(
                        "[WEATHER]: Auto cycle selected {0} in {1}",
                        WeatherName(weather),
                        scene.RegionInfo.RegionName);
                }
                else
                {
                    m_log.WarnFormat(
                        "[WEATHER]: Auto cycle could not start {0} in {1}",
                        WeatherName(weather),
                        scene.RegionInfo.RegionName);
                }
            }
            catch (Exception e)
            {
                string regionName = m_scene == null ? "unknown region" : m_scene.RegionInfo.RegionName;
                m_log.WarnFormat("[WEATHER]: Auto cycle failed in {0}: {1}", regionName, e);
            }
            finally
            {
                Interlocked.Exchange(ref m_autoCycleBusy, 0);
                ScheduleNextAutoCycle();
            }
        }

        private void ScheduleNextAutoCycle()
        {
            ScheduleAutoCycle(AutoCycleIntervalMS());
        }

        private void ScheduleAutoCycle(int dueTimeMS)
        {
            Timer timer = m_autoCycleTimer;
            if (timer == null || m_scene == null)
                return;

            dueTimeMS = Math.Max(1000, dueTimeMS);
            m_nextAutoCycleTicks = DateTime.Now.Ticks + dueTimeMS * 10000L;
            timer.Change(dueTimeMS, Timeout.Infinite);

            ScheduleAutoCycleWarning(dueTimeMS);
        }

        private void ScheduleAutoCycleWarning(int dueTimeMS)
        {
            Timer warningTimer = m_autoCycleWarningTimer;
            if (warningTimer == null || m_autoCycleForecastWarningMinutes <= 0 || string.IsNullOrEmpty(m_autoCycleForecastWarningMessage))
                return;

            int warningLeadMS = m_autoCycleForecastWarningMinutes * 60 * 1000;
            int warningDueMS = dueTimeMS - warningLeadMS;
            if (warningDueMS <= 0)
            {
                warningTimer.Change(Timeout.Infinite, Timeout.Infinite);
                return;
            }

            warningTimer.Change(warningDueMS, Timeout.Infinite);
        }

        private void AutoCycleForecastWarningElapsed(object state)
        {
            Scene scene = m_scene;
            if (scene == null || string.IsNullOrEmpty(m_autoCycleForecastWarningMessage))
                return;

            WeatherKind nextWeather;
            lock (m_sync)
            {
                if (!m_hasPendingAutoCycleWeather)
                {
                    m_pendingAutoCycleWeather = PickAutoCycleWeather();
                    m_hasPendingAutoCycleWeather = true;
                }

                nextWeather = m_pendingAutoCycleWeather;
            }

            string message = FormatForecastWarningMessage(scene, nextWeather);
            scene.ForEachRootScenePresence(sp =>
            {
                if (sp != null && !sp.IsDeleted && sp.ControllingClient != null)
                    SendRegionWeatherMessage(sp, message);
            });
        }

        private int AutoCycleIntervalMS()
        {
            double intervalMS = m_autoCycleHours * 60d * 60d * 1000d;
            return (int)Math.Max(1000d, Math.Min(int.MaxValue, intervalMS));
        }

        private WeatherKind PickAutoCycleWeather()
        {
            WeatherKind current;
            lock (m_sync)
                current = m_currentWeather;

            if (m_autoCyclePressureDriven)
                return PickPressureDrivenWeather(current);

            lock (m_randomSync)
            {
                for (int attempt = 0; attempt < 8; attempt++)
                {
                    WeatherKind weather = m_autoCycleChoices[m_random.Next(m_autoCycleChoices.Count)];
                    if (m_autoCycleChoices.Count == 1 || weather != current)
                        return weather;
                }

                return m_autoCycleChoices[m_random.Next(m_autoCycleChoices.Count)];
            }
        }

        // Fair (Clear/Sunny), moderate (Rain/Snow), and severe (Storm/
        // Blizzard) bands, low pressure = severe - same real-meteorology
        // direction Gemini's reference script used. Deliberately doesn't
        // try to pick Rain vs. Snow (or any hemisphere/season guess) -
        // that's left entirely to whichever of the two an admin actually
        // configured into AutoCycleWeatherChoices, same as the existing
        // random picker already respects that list.
        private static WeatherSeverity SeverityOf(WeatherKind weather)
        {
            switch (weather)
            {
                case WeatherKind.Storm:
                case WeatherKind.Blizzard:
                    return WeatherSeverity.Severe;
                case WeatherKind.Rain:
                case WeatherKind.Snow:
                    return WeatherSeverity.Moderate;
                default:
                    return WeatherSeverity.Fair;
            }
        }

        private enum WeatherSeverity
        {
            Fair,
            Moderate,
            Severe
        }

        private WeatherKind PickPressureDrivenWeather(WeatherKind current)
        {
            lock (m_randomSync)
            {
                // Small chance each tick of a new pressure system moving in;
                // otherwise keep drifting toward the last-rolled target. This
                // mirrors a real pressure trend building over several ticks
                // instead of resetting every single time.
                if (m_random.NextDouble() < 0.35)
                    m_simulatedPressureTargetHPa = 970f + (float)(m_random.NextDouble() * 60f); // 970-1030 hPa

                m_simulatedPressureHPa +=
                        (m_simulatedPressureTargetHPa - m_simulatedPressureHPa) * 0.45f;

                WeatherSeverity band;
                if (m_simulatedPressureHPa < 995f)
                    band = WeatherSeverity.Severe;
                else if (m_simulatedPressureHPa < 1012f)
                    band = WeatherSeverity.Moderate;
                else
                    band = WeatherSeverity.Fair;

                List<WeatherKind> candidates = new List<WeatherKind>();
                foreach (WeatherKind weather in m_autoCycleChoices)
                {
                    if (SeverityOf(weather) == band)
                        candidates.Add(weather);
                }

                // Nothing configured in this exact band (e.g. only Storm and
                // Sunny are enabled, pressure landed on Moderate) - fall back
                // to the full configured list rather than getting stuck.
                if (candidates.Count == 0)
                    candidates = m_autoCycleChoices;

                for (int attempt = 0; attempt < 8; attempt++)
                {
                    WeatherKind weather = candidates[m_random.Next(candidates.Count)];
                    if (candidates.Count == 1 || weather != current)
                        return weather;
                }

                return candidates[m_random.Next(candidates.Count)];
            }
        }

        private void ParseAutoCycleChoices(string choices)
        {
            m_autoCycleChoices.Clear();

            string[] tokens = (choices ?? string.Empty).Split(',');
            foreach (string rawToken in tokens)
            {
                WeatherKind weather;
                if (TryResolveWeather(rawToken.Trim(), out weather) && !m_autoCycleChoices.Contains(weather))
                    m_autoCycleChoices.Add(weather);
            }

            if (m_autoCycleChoices.Count == 0)
            {
                m_autoCycleChoices.Add(WeatherKind.Storm);
                m_autoCycleChoices.Add(WeatherKind.Rain);
                m_autoCycleChoices.Add(WeatherKind.Snow);
                m_autoCycleChoices.Add(WeatherKind.Blizzard);
                m_autoCycleChoices.Add(WeatherKind.Sunny);
            }
        }

        private string AutoCycleChoiceNames()
        {
            List<string> names = new List<string>(m_autoCycleChoices.Count);
            foreach (WeatherKind weather in m_autoCycleChoices)
                names.Add(WeatherName(weather));

            return string.Join(",", names.ToArray());
        }

        private bool IsCoveredFromSky(float x, float y, float ground, float emitterZ)
        {
            return GetOpenSkyFraction(x, y, 0f, 0f, emitterZ) < 1f;
        }

        private float GetOpenSkyFraction(float centerX, float centerY, float halfWidth, float halfHeight, float emitterZ)
        {
            if (m_scene == null)
                return 1f;

            if (!m_avoidCoveredAreas && !m_useExclusionVolumes)
                return 1f;

            if (!m_scene.SupportsRayCastFiltered() && !m_useExclusionVolumes)
                return 1f;

            int samples = Math.Max(1, m_coverProbeGrid);
            int open = 0;
            int total = 0;

            for (int ix = 0; ix < samples; ix++)
            {
                float fx = samples == 1 ? 0f : ix / (float)(samples - 1) * 2f - 1f;
                for (int iy = 0; iy < samples; iy++)
                {
                    float fy = samples == 1 ? 0f : iy / (float)(samples - 1) * 2f - 1f;
                    float x = centerX + fx * halfWidth;
                    float y = centerY + fy * halfHeight;
                    if (x < 0f || y < 0f || x >= m_scene.RegionInfo.RegionSizeX || y >= m_scene.RegionInfo.RegionSizeY)
                        continue;

                    total++;
                    float ground = m_scene.GetGroundHeight(x, y);
                    if (!RayPointCovered(x, y, ground, emitterZ))
                        open++;
                }
            }

            return total == 0 ? 0f : open / (float)total;
        }

        private bool RayPointCovered(float x, float y, float ground, float emitterZ)
        {
            Scene scene = m_scene;
            if (scene == null)
                return false;

            if (IsInsideExclusionVolume(x, y))
                return true;

            if (!m_avoidCoveredAreas || !scene.SupportsRayCastFiltered())
                return false;

            float startZ = Math.Max(emitterZ + m_coverProbeHeight, ground + m_coverProbeHeight);
            float length = Math.Max(1f, startZ - ground - 0.2f);
            Vector3 start = new Vector3(x, y, startZ);

            try
            {
                RayFilterFlags filter = m_coverIncludesPhantomPrims
                    ? RayFilterFlags.AllPrims
                    : RayFilterFlags.PrimsNonPhantom;

                List<ContactResult> hits = (List<ContactResult>)scene.RayCastFiltered(
                    start,
                    -Vector3.UnitZ,
                    length,
                    m_coverMaxHits,
                    filter);

                if (hits == null || hits.Count == 0)
                    return false;

                foreach (ContactResult hit in hits)
                {
                    SceneObjectPart part = scene.GetSceneObjectPart(hit.ConsumerID);
                    if (part == null)
                        return true;

                    SceneObjectGroup group = part.ParentGroup;
                    if (IsWeatherGeneratedGroup(group))
                        continue;

                    return true;
                }

                return false;
            }
            catch (Exception e)
            {
                m_log.DebugFormat("[WEATHER]: Cover probe failed in {0}: {1}", scene.RegionInfo.RegionName, e.Message);
                return false;
            }
        }

        private SceneObjectGroup CreateEmitter(UUID ownerId, WeatherKind weather, Vector3 position, float radius)
        {
            PrimitiveBaseShape shape = PrimitiveBaseShape.CreateSphere();
            // Was 0.1m - some viewers apply aggressive LOD/impostor simplification
            // to objects that tiny, which can suppress correct particle-system
            // rendering even though the particle data itself is fine (confirmed
            // via reflection against the real compiled method, byte-identical to
            // a working hand-built llParticleSystem() call using the same
            // texture). 1.5m keeps a comfortable margin above any such threshold
            // while still being invisible (alpha=0 own texture).
            shape.Scale = new Vector3(1.5f, 1.5f, 1.5f);
            Primitive.TextureEntry textures = shape.Textures;
            textures.DefaultTexture.RGBA = new Color4(1f, 1f, 1f, 0f);
            shape.Textures = textures;

            SceneObjectPart root = new SceneObjectPart(ownerId, shape, position, Quaternion.Identity, Vector3.Zero);
            root.Name = GeneratedNamePrefix + " " + WeatherName(weather) + " emitter";
            root.Description = GeneratedDescription;
            root.Scale = shape.Scale;
            root.AddFlag(PrimFlags.Phantom);
            // Not TemporaryOnRez: that flag auto-deletes the object ~60s after
            // creation regardless of PSYS_SRC_MAX_AGE. Region coverage mode has
            // no periodic refresh, so every emitter would silently vanish about
            // a minute after "weather rain" - explicit cleanup already happens
            // via ClearWeather/RemoveRegion/Close/CleanupGeneratedObjectsOnStartup.
            root.AddNewParticleSystem(CreateParticleSystem(weather, radius, RandomRange(0.72f, 1.32f)), false);

            SceneObjectGroup group = new SceneObjectGroup(root);
            group.SetGroup(UUID.Zero, null);
            return group;
        }

        private Primitive.ParticleSystem CreateParticleSystem(WeatherKind weather, float radius, float emitterVariance)
        {
            float densityVariance = RandomRange(0.65f, 1.35f);
            float driftVariance = RandomRange(0.75f, 1.25f);

            Primitive.ParticleSystem particles = new Primitive.ParticleSystem
            {
                CRC = 1,
                PartDataFlags = (Primitive.ParticleSystem.ParticleDataFlags)ParticleFlags,
                Pattern = (Primitive.ParticleSystem.SourcePattern)2, // PSYS_SRC_PATTERN_EXPLODE
                Texture = WeatherTexture(weather),
                BurstRadius = radius,
                MaxAge = 0f,
                InnerAngle = 0f,
                OuterAngle = 0f,
                BlendFuncSource = 7, // PSYS_PART_BF_SOURCE_ALPHA
                BlendFuncDest = 9    // PSYS_PART_BF_ONE_MINUS_SOURCE_ALPHA
            };

            if (weather == WeatherKind.Snow || weather == WeatherKind.Blizzard)
            {
                bool blizzard = weather == WeatherKind.Blizzard;
                float snowIntensity = blizzard ? m_intensity * 1.75f : m_intensity;

                particles.PartStartColor = new Color4(1f, 1f, 1f, blizzard ? 0.88f : 0.78f);
                particles.PartEndColor = new Color4(0.95f, 0.98f, 1f, blizzard ? 0.14f : 0.08f);
                particles.PartStartScaleX = blizzard ? 0.4f : 0.3f;
                particles.PartStartScaleY = blizzard ? 0.4f : 0.3f;
                particles.PartEndScaleX = blizzard ? 0.65f : 0.5f;
                particles.PartEndScaleY = blizzard ? 0.65f : 0.5f;
                particles.BurstSpeedMin = blizzard ? 0.35f : 0.05f;
                particles.BurstSpeedMax = blizzard ? 1.4f : 0.22f;
                particles.BurstRate = (blizzard ? RandomRange(0.03f, 0.055f) : RandomRange(0.045f, 0.085f)) * emitterVariance;
                // PartMaxAge/AccelZ chosen together so a particle actually
                // completes the fall from EmitterHeight (default 80m) before
                // expiring: fallDistance ~= 0.5*|AccelZ|*PartMaxAge^2. Blizzard
                // previously covered only ~13m over its own old 5.5s/-0.85
                // values - short of even the old 18m default, a real
                // pre-existing bug independent of this height rework.
                particles.PartMaxAge = blizzard ? 9.2f : 15.0f;
                // Density multiplier (1.2/1.4 below for rain) was tuned so
                // conservatively that with Intensity at its own default
                // (1.0) and densityVariance averaging ~1.0, a burst produced
                // only 1-3 particles - nowhere near the 5-50 caps this same
                // formula is clamped against. Confirmed by a live tester,
                // 2026-09-14: storm/blizzard "could be quadrupled" and plain
                // rain was barely visible at all. Raised 4x to actually use
                // the headroom the caps already allowed; the one cap that
                // 4x would otherwise clip (non-blizzard snow) raised to
                // match.
                particles.BurstPartCount = (byte)Clamp((int)Math.Ceiling(4.8f * snowIntensity * densityVariance), 1, blizzard ? 16 : 8);
                Vector2 snowWind = WeatherWindVector(weather, driftVariance);
                particles.PartAcceleration = new Vector3(snowWind.X, snowWind.Y, blizzard ? -2.0f : -0.75f);
                return particles;
            }

            bool storm = weather == WeatherKind.Storm;
            float rainIntensity = storm ? m_intensity * 1.75f : m_intensity;

            particles.PartStartColor = storm
                ? new Color4(0.66f, 0.69f, 0.74f, 0.94f)
                : new Color4(0.7f, 0.73f, 0.76f, 0.86f);
            particles.PartEndColor = storm
                ? new Color4(0.5f, 0.54f, 0.6f, 0.1f)
                : new Color4(0.56f, 0.6f, 0.65f, 0.08f);
            particles.PartStartScaleX = storm ? 0.038f : 0.032f;
            particles.PartStartScaleY = storm ? 0.38f : 0.3f;
            particles.PartEndScaleX = storm ? 0.024f : 0.022f;
            particles.PartEndScaleY = storm ? 0.48f : 0.36f;
            particles.BurstSpeedMin = storm ? 0.65f : 0.38f;
            particles.BurstSpeedMax = storm ? 2.2f : 1.45f;
            particles.BurstRate = (storm ? RandomRange(0.024f, 0.045f) : RandomRange(0.032f, 0.06f)) * emitterVariance;
            // See the snow/blizzard block above for the fall-distance formula
            // this pair is solved against - same ~85m target from the new
            // EmitterHeight default.
            particles.PartMaxAge = storm ? 2.8f : 3.3f;
            // See the snow/blizzard block above - same under-used-headroom
            // fix, same 4x raise.
            particles.BurstPartCount = (byte)Clamp((int)Math.Ceiling(5.6f * rainIntensity * densityVariance), 1, storm ? 50 : 36);
            Vector2 rainWind = WeatherWindVector(weather, driftVariance);
            particles.PartAcceleration = new Vector3(rainWind.X, rainWind.Y, storm ? -22f : -16f);

            return particles;
        }

        private UUID WeatherTexture(WeatherKind weather)
        {
            switch (weather)
            {
                case WeatherKind.Snow:
                    return m_snowTexture;
                case WeatherKind.Blizzard:
                    return m_blizzardTexture;
                case WeatherKind.Storm:
                    return m_stormTexture;
                case WeatherKind.Rain:
                    return m_rainTexture;
                default:
                    return Util.BLANK_TEXTURE_UUID;
            }
        }

        private Vector2 WeatherWindVector(WeatherKind weather, float variance)
        {
            float strength = WeatherWindStrength(weather);
            if (strength <= 0f)
                return Vector2.Zero;

            float angle = m_windDirectionDegrees + RandomRange(-m_windDirectionVarianceDegrees, m_windDirectionVarianceDegrees);
            double radians = angle * Math.PI / 180d;
            return new Vector2(
                (float)Math.Cos(radians) * strength * variance,
                (float)Math.Sin(radians) * strength * variance);
        }

        private float WeatherWindStrength(WeatherKind weather)
        {
            switch (weather)
            {
                case WeatherKind.Storm:
                    return m_stormWindStrength;
                case WeatherKind.Blizzard:
                    return m_blizzardWindStrength;
                case WeatherKind.Snow:
                    return m_snowWindStrength;
                case WeatherKind.Rain:
                    return m_rainWindStrength;
                default:
                    return 0f;
            }
        }

        // The outermost row/column on each axis is biased from a full
        // half-spacing inset (spacing*0.5, symmetric with every interior
        // cell) down to a quarter-spacing inset - interior cells stay
        // evenly spaced, but the two edge cells sit closer to the true
        // region boundary. Confirmed live: at the old uniform half-spacing
        // inset, a real uncovered strip was visible along region edges,
        // worse on larger (2x2/3x3/4x4) regions where MaxEmitters forces
        // wider spacing and the inset grows proportionally.
        private float JitteredCellPosition(int cell, int count, float spacing, int regionSize)
        {
            double center = spacing * (cell + 0.5d);
            if (count > 1 && (cell == 0 || cell == count - 1))
                center = cell == 0 ? spacing * 0.25d : regionSize - spacing * 0.25d;

            double jitter = (RandomUnit() - 0.5d) * spacing * 0.5d;
            float position = (float)(center + jitter);
            return Clamp(position, 1f, regionSize - 1f);
        }

        private float JitterHeight()
        {
            // Was +/-35% - that much variance fought the whole point of a
            // sim-wide-consistent height once EmitterHeight became a large
            // absolute offset (~80m) instead of a small "how far above local
            // dirt" jitter target. +/-10% still avoids a perfectly robotic
            // look without meaningfully reopening the "too low near tall
            // buildings" problem this height rework exists to fix.
            return m_emitterHeight + (float)((RandomUnit() - 0.5d) * m_emitterHeight * 0.1d);
        }

        // Floored at water height (so deep water never leaves an emitter at/
        // under the surface) and otherwise following terrain where terrain
        // rises above water (hills/mountains), so a building on a hilltop
        // can't defeat a flat water-relative ceiling.
        private float TerrainFloor(float x, float y)
        {
            Scene scene = m_scene;
            if (scene == null)
                return 0f;

            float waterHeight = (float)scene.RegionInfo.RegionSettings.WaterHeight;
            return Math.Max(waterHeight, scene.GetGroundHeight(x, y));
        }

        // Sim-wide-consistent emitter altitude. EmitterHeight is meters
        // above TerrainFloor, not meters above local dirt - see
        // JitterHeight's own note.
        private float EmitterBaseHeight(float x, float y)
        {
            return TerrainFloor(x, y) + JitterHeight();
        }

        private float RandomRange(float min, float max)
        {
            return min + (float)RandomUnit() * (max - min);
        }

        private int RandomRange(int min, int max)
        {
            lock (m_randomSync)
                return m_random.Next(min, max);
        }

        private double RandomUnit()
        {
            lock (m_randomSync)
                return m_random.NextDouble();
        }

        private void ClearWeather(bool log, bool restoreState, bool forceRestore = false)
        {
            lock (m_weatherChangeSync)
            {
                StopStormEffects();
                StopActiveAreaRefresh();
                StopWanderingRefresh();

                List<SceneObjectGroup> emitters;
                lock (m_sync)
                {
                    emitters = new List<SceneObjectGroup>(m_emitters);
                    m_emitters.Clear();
                    m_activeEmitterCells.Clear();
                    m_currentWeather = WeatherKind.Clear;
                }

                DeleteEmitters(emitters);

                if (restoreState)
                {
                    RestoreClouds(forceRestore);
                    RestoreWind(forceRestore);
                }

                if (forceRestore)
                    ClearSurfacePatches(true);
                else if (m_surfaceEffectsEnabled)
                    QueueSurfaceUpdate(true);

                if (log && m_scene != null)
                    m_log.InfoFormat("[WEATHER]: Cleared weather in {0}", m_scene.RegionInfo.RegionName);
            }
        }

        private void StartStormEffects(UUID ownerId)
        {
            if (!m_lightningEnabled && (!m_thunderEnabled || m_thunderSound.IsZero()))
                return;

            int generation = Interlocked.Increment(ref m_stormEffectGeneration);
            Util.FireAndForget(
                o => StormEffectLoop(generation, ownerId),
                null,
                "WeatherModule.StormEffects",
                false);
        }

        private void StopStormEffects()
        {
            Interlocked.Increment(ref m_stormEffectGeneration);
        }

        private void StormEffectLoop(int generation, UUID ownerId)
        {
            while (generation == m_stormEffectGeneration && IsCurrentWeather(WeatherKind.Storm))
            {
                Thread.Sleep(RandomRange(m_lightningMinDelayMS, m_lightningMaxDelayMS + 1));

                if (m_scene == null || generation != m_stormEffectGeneration || !IsCurrentWeather(WeatherKind.Storm))
                    return;

                TriggerLightning(ownerId, generation);
            }
        }

        private bool IsCurrentWeather(WeatherKind weather)
        {
            lock (m_sync)
                return m_currentWeather == weather;
        }

        private void TriggerLightning(UUID ownerId, int generation)
        {
            lock (m_weatherChangeSync)
            {
                if (m_scene == null
                    || generation != m_stormEffectGeneration
                    || !IsCurrentWeather(WeatherKind.Storm))
                {
                    return;
                }

                Vector3 position = GetLightningPosition(out float flashHeight);

                if (m_lightningEnabled)
                    CreateLightningFlash(ownerId, position, flashHeight);

                if (m_thunderEnabled && !m_thunderSound.IsZero())
                {
                    Util.FireAndForget(
                        o =>
                        {
                            Thread.Sleep(RandomRange(450, 1900));
                            lock (m_weatherChangeSync)
                            {
                                if (generation == m_stormEffectGeneration && IsCurrentWeather(WeatherKind.Storm))
                                    SendThunder(position);
                            }
                        },
                        null,
                        "WeatherModule.Thunder",
                        false);
                }
            }
        }

        private Vector3 GetLightningPosition(out float flashHeight)
        {
            Scene scene = m_scene;
            int sizeX = Math.Max(1, (int)scene.RegionInfo.RegionSizeX);
            int sizeY = Math.Max(1, (int)scene.RegionInfo.RegionSizeY);
            float marginX = Math.Min(6f, Math.Max(0f, (sizeX - 1f) * 0.25f));
            float marginY = Math.Min(6f, Math.Max(0f, (sizeY - 1f) * 0.25f));
            List<ScenePresence> avatars = new List<ScenePresence>();

            scene.ForEachRootScenePresence(sp =>
            {
                if (sp != null && !sp.IsDeleted && !sp.IsChildAgent)
                    avatars.Add(sp);
            });

            // Bolt length used to be a fixed 26-46m, tuned back when
            // EmitterHeight defaulted to ~18m - centered a couple meters
            // above that, it reached close enough to the ground to read as
            // a real strike. Once EmitterHeight became a sim-wide-consistent
            // ~80m (see JitterHeight's own note), that same fixed length
            // left the bolt floating entirely between roughly 60-120m up,
            // never visibly reaching the ground at all. Scale the length
            // with EmitterHeight instead so it keeps reaching down to near
            // the ground at any configured height - found live, 2026-09-14.
            flashHeight = Math.Max(12f, (m_emitterHeight - 3f) * RandomRange(0.8f, 1f));
            Vector3 fallback = new Vector3(sizeX * 0.5f, sizeY * 0.5f, flashHeight * 0.5f);
            for (int attempt = 0; attempt < 12; attempt++)
            {
                float x;
                float y;
                if (avatars.Count > 0)
                {
                    ScenePresence avatar = avatars[RandomRange(0, avatars.Count)];
                    x = Clamp(avatar.AbsolutePosition.X + RandomRange(-52f, 52f), marginX, Math.Max(marginX, sizeX - marginX));
                    y = Clamp(avatar.AbsolutePosition.Y + RandomRange(-52f, 52f), marginY, Math.Max(marginY, sizeY - marginY));
                }
                else
                {
                    x = RandomRange(marginX, Math.Max(marginX + 0.01f, sizeX - marginX));
                    y = RandomRange(marginY, Math.Max(marginY + 0.01f, sizeY - marginY));
                }

                float ground = scene.GetGroundHeight(x, y);
                float floorZ = TerrainFloor(x, y);
                // Center the bolt so its bottom sits a couple meters above
                // the ground (visual clearance, no terrain clipping) and its
                // top reaches up toward cloud height - a real strike
                // spanning the two, not a segment floating in between.
                fallback = new Vector3(x, y, floorZ + 2f + flashHeight * 0.5f);
                if (!IsCoveredFromSky(x, y, ground, floorZ + m_emitterHeight))
                    return fallback;
            }

            return fallback;
        }

        private void CreateLightningFlash(UUID ownerId, Vector3 position, float flashHeight)
        {
            PrimitiveBaseShape shape = PrimitiveBaseShape.CreateCylinder();
            shape.Scale = new Vector3(0.55f, 0.55f, flashHeight);

            Primitive.TextureEntry textures = shape.Textures;
            textures.DefaultTexture.TextureID = m_lightningTexture;
            textures.DefaultTexture.RGBA = new Color4(0.96f, 0.98f, 1f, 1f);
            textures.DefaultTexture.Fullbright = true;
            textures.DefaultTexture.Glow = 1f;
            shape.Textures = textures;

            SceneObjectPart root = new SceneObjectPart(ownerId, shape, position, Quaternion.Identity, Vector3.Zero);
            root.Name = GeneratedNamePrefix + " lightning flash";
            root.Description = GeneratedDescription;
            root.Scale = shape.Scale;
            root.AddFlag(PrimFlags.Phantom);
            root.AddFlag(PrimFlags.TemporaryOnRez);

            SceneObjectGroup flash = new SceneObjectGroup(root);
            flash.TemporaryInstance = true;
            flash.SetGroup(UUID.Zero, null);

            if (!m_scene.AddNewSceneObject(flash, false))
                return;

            flash.RootPart.SendFullUpdateToAllClients();
            flash.ScheduleGroupForUpdate(PrimUpdateFlags.FullUpdate);

            m_activeLightningFlashes[flash.UUID] = DateTime.UtcNow;

            Util.FireAndForget(
                o =>
                {
                    Thread.Sleep(RandomRange(420, 820));
                    DeleteLightningFlash(flash);
                },
                null,
                "WeatherModule.LightningFlash",
                false);
        }

        private void DeleteLightningFlash(SceneObjectGroup flash)
        {
            if (flash != null)
                m_activeLightningFlashes.TryRemove(flash.UUID, out _);

            if (m_scene == null || flash == null || flash.IsDeleted)
                return;

            try
            {
                m_scene.DeleteSceneObject(flash, false, false);
            }
            catch (Exception e)
            {
                m_log.DebugFormat("[WEATHER]: Failed to delete lightning flash {0}: {1}", flash.UUID, e.Message);
            }
        }

        private void StartLightningSweepTimer()
        {
            StopLightningSweepTimer();
            m_lightningSweepTimer = new Timer(LightningSweepTimerElapsed, null, LightningSweepIntervalMS, LightningSweepIntervalMS);
        }

        private void StopLightningSweepTimer()
        {
            Timer timer = Interlocked.Exchange(ref m_lightningSweepTimer, null);
            if (timer != null)
                timer.Dispose();
        }

        private void LightningSweepTimerElapsed(object state)
        {
            if (Interlocked.Exchange(ref m_lightningSweepBusy, 1) != 0)
                return;

            try
            {
                Scene scene = m_scene;
                if (scene == null || m_activeLightningFlashes.IsEmpty)
                    return;

                DateTime cutoff = DateTime.UtcNow - LightningStuckAge;
                foreach (KeyValuePair<UUID, DateTime> entry in m_activeLightningFlashes)
                {
                    if (entry.Value > cutoff)
                        continue;

                    if (!m_activeLightningFlashes.TryRemove(entry.Key, out _))
                        continue;

                    SceneObjectGroup stuck = scene.GetSceneObjectGroup(entry.Key);
                    if (stuck == null || stuck.IsDeleted)
                        continue;

                    m_log.WarnFormat(
                        "[WEATHER]: Force-removing stuck lightning flash {0} in {1} (exceeded {2}s expected lifetime).",
                        entry.Key, scene.RegionInfo.RegionName, LightningStuckAge.TotalSeconds);

                    try
                    {
                        scene.DeleteSceneObject(stuck, false, false);
                    }
                    catch (Exception e)
                    {
                        m_log.DebugFormat("[WEATHER]: Failed to force-remove stuck lightning flash {0}: {1}", entry.Key, e.Message);
                    }
                }
            }
            finally
            {
                Interlocked.Exchange(ref m_lightningSweepBusy, 0);
            }
        }

        private void SendThunder(Vector3 position)
        {
            Scene scene = m_scene;
            if (scene == null)
                return;

            scene.ForEachRootScenePresence(sp =>
            {
                if (sp == null || sp.IsDeleted || sp.ControllingClient == null)
                    return;

                sp.ControllingClient.SendTriggeredSound(
                    m_thunderSound,
                    UUID.Zero,
                    UUID.Zero,
                    UUID.Zero,
                    scene.RegionInfo.RegionHandle,
                    position,
                    m_thunderVolume);
            });
        }

        private void LoadEnvironmentProfiles(IConfigSource source)
        {
            // No Sunny entry - see CreateDefaultEnvironmentProfile's note;
            // Sunny now behaves like Clear (no environment override at all).
            m_environmentProfiles[WeatherKind.Rain] = LoadEnvironmentProfile(
                source.Configs["Weather.Environment.Rain"], CreateDefaultEnvironmentProfile(WeatherKind.Rain));
            m_environmentProfiles[WeatherKind.Storm] = LoadEnvironmentProfile(
                source.Configs["Weather.Environment.Storm"], CreateDefaultEnvironmentProfile(WeatherKind.Storm));
            m_environmentProfiles[WeatherKind.Snow] = LoadEnvironmentProfile(
                source.Configs["Weather.Environment.Snow"], CreateDefaultEnvironmentProfile(WeatherKind.Snow));
            m_environmentProfiles[WeatherKind.Blizzard] = LoadEnvironmentProfile(
                source.Configs["Weather.Environment.Blizzard"], CreateDefaultEnvironmentProfile(WeatherKind.Blizzard));
        }

        private EnvironmentProfile LoadEnvironmentProfile(IConfig config, EnvironmentProfile defaults)
        {
            EnvironmentProfile profile = defaults.Clone();
            if (config == null)
                return profile;

            profile.CloudCoverage = Clamp(config.GetFloat("CloudCoverage", profile.CloudCoverage), 0f, 1f);
            profile.CloudScale = Math.Max(0f, config.GetFloat("CloudScale", profile.CloudScale));
            profile.CloudColor = ReadVector4(config, "CloudColor", profile.CloudColor);
            profile.CloudXYDensity = ReadVector3(config, "CloudXYDensity", profile.CloudXYDensity);
            profile.CloudDetailXYDensity = ReadVector3(config, "CloudDetailXYDensity", profile.CloudDetailXYDensity);
            profile.CloudScrollX = config.GetFloat("CloudScrollX", profile.CloudScrollX);
            profile.CloudScrollY = config.GetFloat("CloudScrollY", profile.CloudScrollY);
            profile.Horizon = ReadVector4(config, "Horizon", profile.Horizon);
            profile.BlueDensity = ReadVector4(config, "BlueDensity", profile.BlueDensity);
            profile.AmbientMultiplier = Math.Max(0f, config.GetFloat("AmbientMultiplier", profile.AmbientMultiplier));
            profile.SunMoonColorMultiplier = Math.Max(0f, config.GetFloat("SunMoonColorMultiplier", profile.SunMoonColorMultiplier));
            profile.HazeHorizon = Math.Max(0f, config.GetFloat("HazeHorizon", profile.HazeHorizon));
            profile.HazeDensity = Math.Max(0f, config.GetFloat("HazeDensity", profile.HazeDensity));
            profile.DensityMultiplier = Math.Max(0f, config.GetFloat("DensityMultiplier", profile.DensityMultiplier));
            profile.DistanceMultiplier = Math.Max(0f, config.GetFloat("DistanceMultiplier", profile.DistanceMultiplier));
            profile.SunGlowFocus = config.GetFloat("SunGlowFocus", profile.SunGlowFocus);
            profile.SunGlowSize = Math.Max(0f, config.GetFloat("SunGlowSize", profile.SunGlowSize));
            profile.SceneGammaMultiplier = Math.Max(0.01f, config.GetFloat("SceneGammaMultiplier", profile.SceneGammaMultiplier));
            profile.DrawClassicClouds = config.GetBoolean("DrawClassicClouds", profile.DrawClassicClouds);
            profile.CloudScrollXLock = config.GetBoolean("CloudScrollXLock", profile.CloudScrollXLock);
            profile.CloudScrollYLock = config.GetBoolean("CloudScrollYLock", profile.CloudScrollYLock);
            return profile;
        }

        // No WeatherKind.Sunny branch: "Sunny" was a separate hardcoded
        // bright-daytime override, which is redundant with Clear (which
        // already restores the real, saved environment - correct on its
        // own during the day, and the only correct choice at night, which
        // a hardcoded "sunny" look can never be). Sunny is no longer
        // registered in m_environmentProfiles at all, so it now behaves
        // exactly like Clear for environment purposes (see ApplyClouds's
        // early-return on a missing profile).
        private static EnvironmentProfile CreateDefaultEnvironmentProfile(WeatherKind weather)
        {
            if (weather == WeatherKind.Storm)
            {
                return new EnvironmentProfile
                {
                    CloudCoverage = 0.94f,
                    CloudScale = 0.72f,
                    CloudColor = new Vector4(0.06f, 0.07f, 0.085f, 1f),
                    CloudXYDensity = new Vector3(1.35f, 0.64f, 1.0f),
                    CloudDetailXYDensity = new Vector3(1.55f, 0.72f, 0.28f),
                    CloudScrollX = 0.48f,
                    CloudScrollY = 0.1f,
                    Horizon = new Vector4(0.08f, 0.09f, 0.11f, 1f),
                    BlueDensity = new Vector4(0.04f, 0.055f, 0.08f, 1f),
                    AmbientMultiplier = 0.55f,
                    SunMoonColorMultiplier = 0.5f,
                    HazeHorizon = 0.45f,
                    HazeDensity = 0.78f,
                    DensityMultiplier = 0.32f,
                    DistanceMultiplier = 0.8f,
                    SunGlowFocus = 0.05f,
                    SunGlowSize = 1.2f,
                    SceneGammaMultiplier = 0.8f,
                };
            }

            if (weather == WeatherKind.Snow)
            {
                return new EnvironmentProfile
                {
                    CloudCoverage = 0.86f,
                    CloudScale = 0.7f,
                    CloudColor = new Vector4(0.38f, 0.4f, 0.44f, 1f),
                    CloudXYDensity = new Vector3(1.18f, 0.6f, 0.96f),
                    CloudDetailXYDensity = new Vector3(1.28f, 0.62f, 0.22f),
                    CloudScrollX = 0.14f,
                    CloudScrollY = 0.035f,
                    Horizon = new Vector4(0.26f, 0.28f, 0.32f, 1f),
                    BlueDensity = new Vector4(0.13f, 0.15f, 0.2f, 1f),
                    AmbientMultiplier = 0.75f,
                    SunMoonColorMultiplier = 0.75f,
                    HazeHorizon = 0.36f,
                    HazeDensity = 0.6f,
                    DensityMultiplier = 0.24f,
                    DistanceMultiplier = 0.95f,
                    SunGlowFocus = 0.1f,
                    SunGlowSize = 1.6f,
                    SceneGammaMultiplier = 0.92f,
                };
            }

            if (weather == WeatherKind.Blizzard)
            {
                return new EnvironmentProfile
                {
                    CloudCoverage = 0.96f,
                    CloudScale = 0.78f,
                    CloudColor = new Vector4(0.3f, 0.32f, 0.36f, 1f),
                    CloudXYDensity = new Vector3(1.42f, 0.68f, 1.02f),
                    CloudDetailXYDensity = new Vector3(1.6f, 0.74f, 0.3f),
                    CloudScrollX = 0.52f,
                    CloudScrollY = 0.12f,
                    Horizon = new Vector4(0.22f, 0.23f, 0.26f, 1f),
                    BlueDensity = new Vector4(0.1f, 0.12f, 0.16f, 1f),
                    AmbientMultiplier = 0.55f,
                    SunMoonColorMultiplier = 0.55f,
                    HazeHorizon = 0.5f,
                    HazeDensity = 0.85f,
                    DensityMultiplier = 0.34f,
                    DistanceMultiplier = 0.7f,
                    SunGlowFocus = 0.05f,
                    SunGlowSize = 1.2f,
                    SceneGammaMultiplier = 0.85f,
                };
            }

            // Rain (the only remaining fall-through case now that Sunny is
            // gone and Clear never reaches this function at all).
            return new EnvironmentProfile
            {
                CloudCoverage = 0.75f,
                CloudScale = 0.64f,
                CloudColor = new Vector4(0.16f, 0.18f, 0.22f, 1f),
                CloudXYDensity = new Vector3(1.18f, 0.6f, 0.96f),
                CloudDetailXYDensity = new Vector3(1.32f, 0.64f, 0.24f),
                CloudScrollX = 0.28f,
                CloudScrollY = 0.05f,
                Horizon = new Vector4(0.15f, 0.17f, 0.2f, 1f),
                BlueDensity = new Vector4(0.07f, 0.09f, 0.13f, 1f),
                AmbientMultiplier = 0.85f,
                SunMoonColorMultiplier = 0.85f,
                HazeHorizon = 0.4f,
                HazeDensity = 0.62f,
                DensityMultiplier = 0.28f,
                DistanceMultiplier = 0.9f,
                SunGlowFocus = 0.08f,
                SunGlowSize = 1.4f,
                SceneGammaMultiplier = 0.88f,
            };
        }

        private static Vector3 ReadVector3(IConfig config, string key, Vector3 fallback)
        {
            string raw = config.GetString(key, string.Empty).Trim();
            if (string.IsNullOrEmpty(raw))
                return fallback;

            string[] parts = raw.Split(',');
            if (parts.Length != 3
                || !float.TryParse(parts[0].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float x)
                || !float.TryParse(parts[1].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float y)
                || !float.TryParse(parts[2].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float z))
                return fallback;

            return new Vector3(x, y, z);
        }

        private static Vector4 ReadVector4(IConfig config, string key, Vector4 fallback)
        {
            string raw = config.GetString(key, string.Empty).Trim();
            if (string.IsNullOrEmpty(raw))
                return fallback;

            string[] parts = raw.Split(',');
            if (parts.Length != 4
                || !float.TryParse(parts[0].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float x)
                || !float.TryParse(parts[1].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float y)
                || !float.TryParse(parts[2].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float z)
                || !float.TryParse(parts[3].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float w))
                return fallback;

            return new Vector4(x, y, z, w);
        }

        private void StartSurfaceTimer()
        {
            if (!m_surfaceEffectsEnabled || m_scene == null)
                return;

            StopSurfaceTimer();
            m_lastSurfaceUpdateUtc = DateTime.UtcNow;
            int period = m_surfaceUpdateSeconds * 1000;
            m_surfaceTimer = new Timer(SurfaceTimerElapsed, null, 1000, period);
        }

        private void StopSurfaceTimer()
        {
            Timer timer = Interlocked.Exchange(ref m_surfaceTimer, null);
            if (timer != null)
                timer.Dispose();
        }

        private void StartAuroraTimer()
        {
            if (!m_auroraEnabled || m_scene == null)
                return;

            StopAuroraTimer();
            int period = m_auroraUpdateSeconds * 1000;
            m_auroraTimer = new Timer(AuroraTimerElapsed, null, 2000, period);
        }

        private void StopAuroraTimer()
        {
            Timer timer = Interlocked.Exchange(ref m_auroraTimer, null);
            if (timer != null)
                timer.Dispose();
        }

        private void AuroraTimerElapsed(object state)
        {
            if (Interlocked.Exchange(ref m_auroraBusy, 1) != 0)
                return;

            try
            {
                UpdateAurora();
            }
            catch (Exception e)
            {
                m_log.WarnFormat("[WEATHER]: Aurora update failed: {0}", e.Message);
            }
            finally
            {
                Interlocked.Exchange(ref m_auroraBusy, 0);
            }
        }

        // Same daylight-fade shape AyaneStorm's client-rendered aurora uses
        // (ASAuroraSunFadeAngle, 6-degree fade band) - reimplemented here
        // against IEnvironmentModule.GetRegionSunDir instead of the viewer's
        // own sky-dome sun direction, since this runs server-side.
        private float CurrentAuroraDaylightFade()
        {
            if (m_environmentModule == null)
                return 0f;

            Vector3 sunDir = m_environmentModule.GetRegionSunDir(0f);
            float sunElevationDeg = (float)(Math.Asin(Clamp(sunDir.Z, -1f, 1f)) * (180.0 / Math.PI));
            return 1f - Clamp((sunElevationDeg - m_auroraSunFadeAngle) / 6f, 0f, 1f);
        }

        private void UpdateAurora()
        {
            if (!m_auroraEnabled || m_scene == null || m_environmentModule == null)
            {
                RemoveAuroraEmitters();
                return;
            }

            float daylightFade = CurrentAuroraDaylightFade();
            if (daylightFade <= 0.01f)
            {
                RemoveAuroraEmitters();
                return;
            }

            float effectiveIntensity = m_auroraIntensity * daylightFade;

            if (m_auroraEmitters.Count == 0)
            {
                CreateAuroraEmitters(effectiveIntensity);
            }
            else
            {
                foreach (SceneObjectGroup emitter in m_auroraEmitters)
                {
                    if (emitter == null || emitter.IsDeleted)
                        continue;
                    emitter.RootPart.AddNewParticleSystem(CreateAuroraParticleSystem(effectiveIntensity), false);
                }
            }
        }

        // Same grid-across-the-region shape GetEmitterLayout already uses for
        // rain/snow (see the "Requested emitter layout NxN" log line), just
        // with much wider spacing - a single centered emitter, capped at the
        // viewer's ~50m PSYS_SRC_BURST_RADIUS like every other emitter here,
        // is invisible from most of a var region (confirmed live on a 512x512
        // region: nothing visible away from dead-center). AuroraCoverage
        // scales sparsity by skipping cells, not by shrinking radius.
        private void CreateAuroraEmitters(float effectiveIntensity)
        {
            if (m_scene == null)
                return;

            int sizeX = Math.Max(1, (int)m_scene.RegionInfo.RegionSizeX);
            int sizeY = Math.Max(1, (int)m_scene.RegionInfo.RegionSizeY);
            const float auroraSpacingMeters = 200f;
            const int maxAuroraCells = 36;

            int countX = Math.Max(1, (int)Math.Ceiling(sizeX / auroraSpacingMeters));
            int countY = Math.Max(1, (int)Math.Ceiling(sizeY / auroraSpacingMeters));
            while (countX * countY > maxAuroraCells)
            {
                if (countX >= countY && countX > 1)
                    countX--;
                else if (countY > 1)
                    countY--;
                else
                    break;
            }

            float spacingX = sizeX / (float)countX;
            float spacingY = sizeY / (float)countY;

            for (int x = 0; x < countX; x++)
            {
                for (int y = 0; y < countY; y++)
                {
                    // Coverage thins out which cells actually spawn an
                    // emitter, not each emitter's own radius - a sparse
                    // aurora should still look full-strength where it does
                    // appear, not faint everywhere.
                    if (RandomRange(0f, 1f) > m_auroraCoverage)
                        continue;

                    float posX = Clamp((x + 0.5f) * spacingX + RandomRange(-spacingX * 0.2f, spacingX * 0.2f), 0f, sizeX - 1f);
                    float posY = Clamp((y + 0.5f) * spacingY + RandomRange(-spacingY * 0.2f, spacingY * 0.2f), 0f, sizeY - 1f);
                    float groundHeight = m_scene.Heightmap.GetHeight(posX, posY);
                    Vector3 position = new Vector3(posX, posY, groundHeight + m_auroraHeight);

                    PrimitiveBaseShape shape = PrimitiveBaseShape.CreateSphere();
                    shape.Scale = new Vector3(0.1f, 0.1f, 0.1f);
                    Primitive.TextureEntry textures = shape.Textures;
                    textures.DefaultTexture.RGBA = new Color4(1f, 1f, 1f, 0f);
                    shape.Textures = textures;

                    SceneObjectPart root = new SceneObjectPart(m_weatherOwnerId, shape, position, Quaternion.Identity, Vector3.Zero);
                    root.Name = GeneratedNamePrefix + " Aurora emitter";
                    root.Description = GeneratedDescription;
                    root.Scale = shape.Scale;
                    root.AddFlag(PrimFlags.Phantom);
                    root.AddNewParticleSystem(CreateAuroraParticleSystem(effectiveIntensity), false);

                    SceneObjectGroup group = new SceneObjectGroup(root);
                    group.SetGroup(UUID.Zero, null);

                    if (!m_scene.AddNewSceneObject(group, false))
                    {
                        m_log.Warn("[WEATHER]: Failed to add an aurora emitter to the scene.");
                        continue;
                    }

                    m_auroraEmitters.Add(group);
                }
            }

            if (m_auroraEmitters.Count == 0)
            {
                m_log.Info("[WEATHER]: Aurora coverage roll skipped every grid cell this pass; will retry next update.");
            }
        }

        private Primitive.ParticleSystem CreateAuroraParticleSystem(float effectiveIntensity)
        {
            // A wide, sparse, slow-drifting burst high above the region -
            // large soft glow patches rather than a dense falling effect,
            // deliberately unlike the rain/snow emitters this pattern is
            // otherwise modeled on.
            float coverageRadius = Math.Max(
                32f,
                Math.Min(m_scene.RegionInfo.RegionSizeX, m_scene.RegionInfo.RegionSizeY) * 0.6f);
            coverageRadius = Math.Min(coverageRadius, 50f); // PSYS_SRC_BURST_RADIUS viewer clamp

            Primitive.ParticleSystem particles = new Primitive.ParticleSystem
            {
                CRC = 1,
                PartDataFlags = (Primitive.ParticleSystem.ParticleDataFlags)ParticleFlags,
                Pattern = (Primitive.ParticleSystem.SourcePattern)2, // PSYS_SRC_PATTERN_EXPLODE
                Texture = m_auroraTexture,
                BurstRadius = coverageRadius,
                MaxAge = 0f,
                InnerAngle = 0f,
                OuterAngle = 0f,
                BlendFuncSource = 7, // PSYS_PART_BF_SOURCE_ALPHA
                BlendFuncDest = 1,   // PSYS_PART_BF_ONE - additive glow, not alpha-composited like rain/snow
                PartStartColor = new Color4(m_auroraLowColor.X, m_auroraLowColor.Y, m_auroraLowColor.Z, Clamp(m_auroraLowColor.W * effectiveIntensity, 0f, 1f)),
                PartEndColor = new Color4(m_auroraHighColor.X, m_auroraHighColor.Y, m_auroraHighColor.Z, Clamp(m_auroraHighColor.W * effectiveIntensity, 0f, 1f)),
                PartStartScaleX = 14f,
                PartStartScaleY = 22f,
                PartEndScaleX = 22f,
                PartEndScaleY = 34f,
                BurstSpeedMin = 0.01f,
                BurstSpeedMax = 0.05f,
                PartMaxAge = 22f,
                PartAcceleration = new Vector3(RandomRange(-0.02f, 0.02f), RandomRange(-0.02f, 0.02f), 0f)
            };

            float coverageDensity = Math.Max(0.05f, m_auroraCoverage);
            particles.BurstRate = RandomRange(1.4f, 2.2f) / coverageDensity;
            particles.BurstPartCount = (byte)Clamp((int)Math.Ceiling(2f * coverageDensity), 1, 6);

            return particles;
        }

        private void RemoveAuroraEmitters()
        {
            if (m_auroraEmitters.Count == 0)
                return;

            foreach (SceneObjectGroup emitter in m_auroraEmitters)
            {
                if (m_scene == null || emitter == null || emitter.IsDeleted)
                    continue;

                try
                {
                    m_scene.DeleteSceneObject(emitter, false, false);
                }
                catch (Exception e)
                {
                    m_log.WarnFormat("[WEATHER]: Failed to remove an aurora emitter: {0}", e.Message);
                }
            }

            m_auroraEmitters.Clear();
        }

        private void QueueSurfaceUpdate(bool immediate)
        {
            if (!m_surfaceEffectsEnabled)
                return;

            Timer timer = m_surfaceTimer;
            if (timer != null && immediate)
                timer.Change(0, m_surfaceUpdateSeconds * 1000);
        }

        private void SurfaceTimerElapsed(object state)
        {
            if (Interlocked.Exchange(ref m_surfaceBusy, 1) != 0)
                return;

            try
            {
                lock (m_weatherChangeSync)
                    UpdateSurfaceStateAndPatches();
            }
            catch (Exception e)
            {
                m_log.WarnFormat("[WEATHER]: Surface-effect update failed: {0}", e.Message);
            }
            finally
            {
                Interlocked.Exchange(ref m_surfaceBusy, 0);
            }
        }

        private void BoostSurfaceForWeather(WeatherKind weather)
        {
            if (!m_surfaceEffectsEnabled)
                return;

            if (weather == WeatherKind.Rain)
                m_wetnessLevel = Clamp(m_wetnessLevel + 0.04f, 0f, 1f);
            else if (weather == WeatherKind.Storm)
                m_wetnessLevel = Clamp(m_wetnessLevel + 0.08f, 0f, 1f);
            else if (weather == WeatherKind.Snow)
            {
                if (m_temperatureC <= m_freezingPointC + 0.5f)
                    m_snowLevel = Clamp(m_snowLevel + 0.05f, 0f, 1f);
                else
                    m_wetnessLevel = Clamp(m_wetnessLevel + 0.025f, 0f, 1f);
            }
            else if (weather == WeatherKind.Blizzard)
            {
                if (m_temperatureC <= m_freezingPointC + 0.5f)
                    m_snowLevel = Clamp(m_snowLevel + 0.1f, 0f, 1f);
                else
                    m_wetnessLevel = Clamp(m_wetnessLevel + 0.05f, 0f, 1f);
            }

            QueueSurfaceUpdate(true);
        }

        private void UpdateSurfaceStateAndPatches()
        {
            DateTime now = DateTime.UtcNow;
            double elapsedHours = Math.Max(0d, (now - m_lastSurfaceUpdateUtc).TotalHours);
            m_lastSurfaceUpdateUtc = now;
            WeatherKind weather = CurrentWeather();

            if (weather == WeatherKind.Rain)
            {
                m_wetnessLevel += (float)(m_rainWetnessPerHour * elapsedHours);
                m_snowLevel -= (float)(m_rainSnowMeltPerHour * elapsedHours);
            }
            else if (weather == WeatherKind.Storm)
            {
                m_wetnessLevel += (float)(m_stormWetnessPerHour * elapsedHours);
                m_snowLevel -= (float)(m_rainSnowMeltPerHour * 1.25f * elapsedHours);
            }
            else if (weather == WeatherKind.Snow)
            {
                if (m_temperatureC <= m_freezingPointC + 0.5f)
                    m_snowLevel += (float)(m_snowAccumulationPerHour * elapsedHours);
                else
                    m_wetnessLevel += (float)(m_rainWetnessPerHour * 0.5f * elapsedHours);
            }
            else if (weather == WeatherKind.Blizzard)
            {
                if (m_temperatureC <= m_freezingPointC + 0.5f)
                    m_snowLevel += (float)(m_snowAccumulationPerHour * 1.75f * elapsedHours);
                else
                    m_wetnessLevel += (float)(m_rainWetnessPerHour * elapsedHours);
            }
            else if (weather == WeatherKind.Sunny)
            {
                m_wetnessLevel -= (float)(m_sunnyDryingPerHour * elapsedHours);
                float meltFactor = m_temperatureC > m_freezingPointC ? 1f + (m_temperatureC - m_freezingPointC) * 0.08f : 0.2f;
                m_snowLevel -= (float)(m_sunnySnowMeltPerHour * meltFactor * elapsedHours);
            }
            else
            {
                m_wetnessLevel -= (float)(m_clearDryingPerHour * elapsedHours);
                float meltFactor = m_temperatureC > m_freezingPointC ? 1f + (m_temperatureC - m_freezingPointC) * 0.05f : 0.1f;
                m_snowLevel -= (float)(m_clearSnowMeltPerHour * meltFactor * elapsedHours);
            }

            m_wetnessLevel = Clamp(m_wetnessLevel, 0f, 1f);
            m_snowLevel = Clamp(m_snowLevel, 0f, 1f);
            RebuildSurfacePatches();
        }

        private void RebuildSurfacePatches()
        {
            Scene scene = m_scene;
            if (!m_surfaceEffectsEnabled || scene == null)
                return;

            SurfaceKind kind;
            float level;
            float startLevel;
            if (m_snowAccumulationEnabled && m_snowLevel >= m_snowPatchStartLevel)
            {
                kind = SurfaceKind.Snow;
                level = m_snowLevel;
                startLevel = m_snowPatchStartLevel;
            }
            else if (m_puddlesEnabled && m_wetnessLevel >= m_puddleStartLevel)
            {
                kind = SurfaceKind.Puddle;
                level = m_wetnessLevel;
                startLevel = m_puddleStartLevel;
            }
            else
            {
                ClearSurfacePatches(false);
                return;
            }

            RefreshExclusionVolumes(false);

            int sizeX = Math.Max(1, (int)scene.RegionInfo.RegionSizeX);
            int sizeY = Math.Max(1, (int)scene.RegionInfo.RegionSizeY);
            float spacing = m_surfacePatchSpacingMeters;
            float normalized = Clamp((level - startLevel) / Math.Max(0.01f, 1f - startLevel), 0f, 1f);
            HashSet<long> candidateKeys = new HashSet<long>();

            scene.ForEachRootScenePresence(sp =>
            {
                if (sp == null || sp.IsDeleted || sp.IsNPC || sp.IsChildAgent)
                    return;

                Vector3 avatarPosition = sp.AbsolutePosition;
                int minCellX = Math.Max(0, (int)Math.Floor((avatarPosition.X - m_surfaceRadiusMeters) / spacing));
                int maxCellX = Math.Min((int)Math.Ceiling(sizeX / spacing) - 1, (int)Math.Floor((avatarPosition.X + m_surfaceRadiusMeters) / spacing));
                int minCellY = Math.Max(0, (int)Math.Floor((avatarPosition.Y - m_surfaceRadiusMeters) / spacing));
                int maxCellY = Math.Min((int)Math.Ceiling(sizeY / spacing) - 1, (int)Math.Floor((avatarPosition.Y + m_surfaceRadiusMeters) / spacing));

                for (int cellX = minCellX; cellX <= maxCellX && candidateKeys.Count < m_maxSurfacePatches; cellX++)
                {
                    for (int cellY = minCellY; cellY <= maxCellY && candidateKeys.Count < m_maxSurfacePatches; cellY++)
                    {
                        float centerX = Math.Min(sizeX - 1f, (cellX + 0.5f) * spacing);
                        float centerY = Math.Min(sizeY - 1f, (cellY + 0.5f) * spacing);
                        float dx = centerX - avatarPosition.X;
                        float dy = centerY - avatarPosition.Y;
                        if (dx * dx + dy * dy > m_surfaceRadiusMeters * m_surfaceRadiusMeters)
                            continue;

                        long key = SurfaceCellKey(cellX, cellY, kind);
                        if (Hash01(key) <= normalized * (kind == SurfaceKind.Snow ? 0.9f : 0.55f))
                            candidateKeys.Add(key);
                    }
                }
            });

            Dictionary<long, SurfaceCandidate> desired = new Dictionary<long, SurfaceCandidate>();
            float waterHeight = (float)scene.RegionInfo.RegionSettings.WaterHeight;

            foreach (long key in candidateKeys)
            {
                DecodeSurfaceCellKey(key, out int cellX, out int cellY, out SurfaceKind cellKind);
                float x = Math.Min(sizeX - 1f, (cellX + 0.5f) * spacing);
                float y = Math.Min(sizeY - 1f, (cellY + 0.5f) * spacing);
                float ground = scene.GetGroundHeight(x, y);

                if (ground <= waterHeight + 0.05f)
                    continue;
                if (TerrainSlopeDegrees(x, y) > m_maxSurfaceSlopeDegrees)
                    continue;
                if (IsCoveredFromSky(x, y, ground, ground + m_emitterHeight))
                    continue;
                if (cellKind == SurfaceKind.Puddle && !IsTerrainLowPoint(x, y))
                    continue;

                float sizeVariance = 0.65f + Hash01(key ^ 0x5f3759dfL) * 0.45f;
                float patchSize = Clamp(spacing * (cellKind == SurfaceKind.Snow ? 0.8f : 0.55f) * sizeVariance, 1.5f, 18f);
                float thickness = cellKind == SurfaceKind.Snow ? 0.045f : 0.02f;
                Vector3 position = new Vector3(x, y, ground + thickness * 0.5f + 0.003f);
                desired[key] = new SurfaceCandidate
                {
                    Kind = cellKind,
                    Position = position,
                    Size = patchSize,
                    Level = level
                };
            }

            List<SceneObjectGroup> obsolete = new List<SceneObjectGroup>();
            List<long> obsoleteKeys = new List<long>();
            foreach (KeyValuePair<long, SurfacePatch> pair in m_surfacePatches)
            {
                if (!desired.ContainsKey(pair.Key))
                {
                    obsoleteKeys.Add(pair.Key);
                    if (pair.Value != null && pair.Value.Group != null)
                        obsolete.Add(pair.Value.Group);
                }
            }

            foreach (long key in obsoleteKeys)
                m_surfacePatches.Remove(key);
            DeleteEmitters(obsolete);

            foreach (KeyValuePair<long, SurfaceCandidate> pair in desired)
            {
                if (m_surfacePatches.ContainsKey(pair.Key))
                    continue;

                SurfaceCandidate candidate = pair.Value;
                SceneObjectGroup patch = CreateSurfacePatch(
                    candidate.Kind,
                    candidate.Position,
                    candidate.Size,
                    candidate.Level);

                if (!scene.AddNewSceneObject(patch, false))
                    continue;

                patch.RootPart.SendFullUpdateToAllClients();
                patch.ScheduleGroupForUpdate(PrimUpdateFlags.FullUpdate);
                m_surfacePatches[pair.Key] = new SurfacePatch
                {
                    Kind = candidate.Kind,
                    Group = patch
                };
            }
        }

        private SceneObjectGroup CreateSurfacePatch(SurfaceKind kind, Vector3 position, float size, float level)
        {
            PrimitiveBaseShape shape = PrimitiveBaseShape.CreateCylinder();
            shape.Scale = new Vector3(size, size, kind == SurfaceKind.Snow ? 0.045f : 0.02f);
            Primitive.TextureEntry textures = shape.Textures;
            textures.DefaultTexture.TextureID = kind == SurfaceKind.Snow ? m_snowSurfaceTexture : m_puddleTexture;
            textures.DefaultTexture.RGBA = kind == SurfaceKind.Snow
                ? new Color4(0.96f, 0.98f, 1f, Clamp(0.2f + level * 0.75f, 0f, 0.95f))
                : new Color4(0.55f, 0.64f, 0.72f, Clamp(0.08f + level * 0.35f, 0f, 0.5f));
            textures.DefaultTexture.Fullbright = false;
            shape.Textures = textures;

            SceneObjectPart root = new SceneObjectPart(m_weatherOwnerId, shape, position, Quaternion.Identity, Vector3.Zero);
            root.Name = kind == SurfaceKind.Snow
                ? GeneratedNamePrefix + " snow accumulation"
                : GeneratedNamePrefix + " puddle";
            root.Description = GeneratedDescription;
            root.Scale = shape.Scale;
            root.AddFlag(PrimFlags.Phantom);
            root.AddFlag(PrimFlags.TemporaryOnRez);
            SceneObjectGroup group = new SceneObjectGroup(root);
            group.TemporaryInstance = true;
            group.SetGroup(UUID.Zero, null);
            return group;
        }

        private void ClearSurfacePatches(bool resetLevels)
        {
            List<SceneObjectGroup> patches = new List<SceneObjectGroup>();
            foreach (SurfacePatch patch in m_surfacePatches.Values)
            {
                if (patch != null && patch.Group != null)
                    patches.Add(patch.Group);
            }
            m_surfacePatches.Clear();
            DeleteEmitters(patches);

            if (resetLevels)
            {
                m_wetnessLevel = 0f;
                m_snowLevel = 0f;
            }
        }

        private float TerrainSlopeDegrees(float x, float y)
        {
            Scene scene = m_scene;
            if (scene == null)
                return 90f;

            float sizeX = scene.RegionInfo.RegionSizeX;
            float sizeY = scene.RegionInfo.RegionSizeY;
            float x0 = Clamp(x - 1f, 0f, sizeX - 1f);
            float x1 = Clamp(x + 1f, 0f, sizeX - 1f);
            float y0 = Clamp(y - 1f, 0f, sizeY - 1f);
            float y1 = Clamp(y + 1f, 0f, sizeY - 1f);
            float dzdx = (scene.GetGroundHeight(x1, y) - scene.GetGroundHeight(x0, y)) / Math.Max(0.1f, x1 - x0);
            float dzdy = (scene.GetGroundHeight(x, y1) - scene.GetGroundHeight(x, y0)) / Math.Max(0.1f, y1 - y0);
            return (float)(Math.Atan(Math.Sqrt(dzdx * dzdx + dzdy * dzdy)) * 180d / Math.PI);
        }

        private bool IsTerrainLowPoint(float x, float y)
        {
            Scene scene = m_scene;
            if (scene == null)
                return false;

            float center = scene.GetGroundHeight(x, y);
            float sum = 0f;
            int count = 0;
            for (int dx = -1; dx <= 1; dx++)
            {
                for (int dy = -1; dy <= 1; dy++)
                {
                    if (dx == 0 && dy == 0)
                        continue;
                    float sx = Clamp(x + dx * 2f, 0f, scene.RegionInfo.RegionSizeX - 1f);
                    float sy = Clamp(y + dy * 2f, 0f, scene.RegionInfo.RegionSizeY - 1f);
                    sum += scene.GetGroundHeight(sx, sy);
                    count++;
                }
            }

            return count > 0 && center <= sum / count + m_puddleLowPointToleranceMeters;
        }

        private static long SurfaceCellKey(int x, int y, SurfaceKind kind)
        {
            return (CellKey(x, y) << 1) | (kind == SurfaceKind.Snow ? 1L : 0L);
        }

        private static void DecodeSurfaceCellKey(long key, out int x, out int y, out SurfaceKind kind)
        {
            kind = (key & 1L) == 1L ? SurfaceKind.Snow : SurfaceKind.Puddle;
            DecodeCellKey(key >> 1, out x, out y);
        }

        private static float Hash01(long key)
        {
            unchecked
            {
                ulong value = (ulong)key;
                value ^= value >> 33;
                value *= 0xff51afd7ed558ccdUL;
                value ^= value >> 33;
                value *= 0xc4ceb9fe1a85ec53UL;
                value ^= value >> 33;
                return (value & 0x00ffffffUL) / 16777215f;
            }
        }

        private void CleanupGeneratedObjects()
        {
            Scene scene = m_scene;
            if (scene == null)
                return;

            List<SceneObjectGroup> delete = new List<SceneObjectGroup>();
            foreach (SceneObjectGroup group in scene.GetSceneObjectGroups())
            {
                if (group == null || group.IsDeleted || group.Backup)
                    continue;

                if (IsWeatherGeneratedGroup(group))
                    delete.Add(group);
            }

            if (delete.Count == 0)
                return;

            DeleteEmitters(delete);
            m_log.WarnFormat(
                "[WEATHER]: Removed {0} non-persistent weather object(s) left in {1} by an earlier module instance.",
                delete.Count,
                scene.RegionInfo.RegionName);
        }

        private bool IsWeatherGeneratedGroup(SceneObjectGroup group)
        {
            if (group == null || group.RootPart == null)
                return false;

            string name = group.Name ?? string.Empty;
            if (name.StartsWith(GeneratedNamePrefix, StringComparison.OrdinalIgnoreCase))
                return true;

            if (group.RootPart.Description == GeneratedDescription)
                return true;

            return string.Equals(name, "weather lightning flash", StringComparison.OrdinalIgnoreCase)
                || name.StartsWith("weather rain emitter", StringComparison.OrdinalIgnoreCase)
                || name.StartsWith("weather storm emitter", StringComparison.OrdinalIgnoreCase)
                || name.StartsWith("weather snow emitter", StringComparison.OrdinalIgnoreCase)
                || string.Equals(name, "weather puddle", StringComparison.OrdinalIgnoreCase)
                || string.Equals(name, "weather snow accumulation", StringComparison.OrdinalIgnoreCase);
        }

        private void RefreshExclusionVolumes(bool force)
        {
            if (!m_useExclusionVolumes)
                return;

            DateTime now = DateTime.UtcNow;
            lock (m_sync)
            {
                if (!force && now < m_nextExclusionRefreshUtc)
                    return;
                m_nextExclusionRefreshUtc = now.AddSeconds(m_exclusionRefreshSeconds);
            }

            Scene scene = m_scene;
            if (scene == null)
                return;

            List<ExclusionVolume> volumes = new List<ExclusionVolume>();
            foreach (SceneObjectGroup group in scene.GetSceneObjectGroups())
            {
                if (group == null || group.IsDeleted || IsWeatherGeneratedGroup(group))
                    continue;

                string name = group.Name ?? string.Empty;
                bool matches = string.Equals(name, m_exclusionObjectName, StringComparison.OrdinalIgnoreCase)
                    || name.StartsWith(m_exclusionObjectName + " ", StringComparison.OrdinalIgnoreCase)
                    || name.StartsWith(m_exclusionObjectName + " -", StringComparison.OrdinalIgnoreCase);

                if (!matches)
                    continue;

                try
                {
                    group.GetAxisAlignedBoundingBoxRaw(
                        out float minX,
                        out float maxX,
                        out float minY,
                        out float maxY,
                        out float minZ,
                        out float maxZ);

                    volumes.Add(new ExclusionVolume
                    {
                        MinX = minX,
                        MaxX = maxX,
                        MinY = minY,
                        MaxY = maxY,
                        MinZ = minZ,
                        MaxZ = maxZ
                    });
                }
                catch (Exception e)
                {
                    m_log.DebugFormat("[WEATHER]: Could not read exclusion volume '{0}': {1}", name, e.Message);
                }
            }

            lock (m_sync)
            {
                m_exclusionVolumes.Clear();
                m_exclusionVolumes.AddRange(volumes);
            }
        }

        private bool IsInsideExclusionVolume(float x, float y)
        {
            if (!m_useExclusionVolumes)
                return false;

            RefreshExclusionVolumes(false);
            lock (m_sync)
            {
                foreach (ExclusionVolume volume in m_exclusionVolumes)
                {
                    if (volume.ContainsXY(x, y))
                        return true;
                }
            }

            return false;
        }

        private void ApplyClouds(WeatherKind weather)
        {
            if (!m_adjustClouds || m_environmentModule == null)
                return;

            // m_savedEnvironment is only the restore point for "weather clear" -
            // each individual weather change must clone from the LIVE
            // environment, not that frozen snapshot, or the sun/moon position
            // (left untouched below) gets stuck at whatever it was when the
            // first weather of the session started instead of continuing to
            // track the region's actual day/night cycle.
            RegionLightShareData current = m_environmentModule.ToLightShare();
            if (current == null)
                return;

            if (m_savedEnvironment == null)
            {
                m_savedEnvironmentWasUnset = RegionEnvironmentWasUnset();
                m_savedEnvironment = CloneLightShare(current);
            }

            if (!m_environmentProfiles.TryGetValue(weather, out EnvironmentProfile profile))
                return;

            RegionLightShareData environment = CloneLightShare(current);
            environment.cloudCoverage = profile.CloudCoverage;
            environment.cloudScale = profile.CloudScale;
            environment.cloudColor = profile.CloudColor;
            environment.cloudXYDensity = profile.CloudXYDensity;
            environment.cloudDetailXYDensity = profile.CloudDetailXYDensity;
            environment.cloudScrollX = profile.CloudScrollX;
            environment.cloudScrollY = profile.CloudScrollY;
            environment.horizon = profile.Horizon;
            environment.blueDensity = profile.BlueDensity;
            // Multiplicative, not absolute - real weather darkens/brightens
            // whatever daylight currently exists, it doesn't replace day
            // with night or erase the admin's own tuned look. starBrightness
            // is deliberately not touched at all (stays whatever `current`
            // already had, via CloneLightShare) - weather never erases night
            // stars or forces them visible during the day.
            environment.ambient = new Vector4(
                current.ambient.X * profile.AmbientMultiplier,
                current.ambient.Y * profile.AmbientMultiplier,
                current.ambient.Z * profile.AmbientMultiplier,
                current.ambient.W);
            environment.sunMoonColor = new Vector4(
                current.sunMoonColor.X * profile.SunMoonColorMultiplier,
                current.sunMoonColor.Y * profile.SunMoonColorMultiplier,
                current.sunMoonColor.Z * profile.SunMoonColorMultiplier,
                current.sunMoonColor.W);
            environment.hazeHorizon = profile.HazeHorizon;
            environment.hazeDensity = profile.HazeDensity;
            environment.densityMultiplier = profile.DensityMultiplier;
            environment.distanceMultiplier = profile.DistanceMultiplier;
            environment.sunGlowFocus = profile.SunGlowFocus;
            environment.sunGlowSize = profile.SunGlowSize;
            environment.sceneGamma = current.sceneGamma * profile.SceneGammaMultiplier;
            // sunMoonPosition/eastAngle/maxAltitude intentionally left untouched
            // (already copied from `current` via CloneLightShare) so weather
            // never overrides the region's day/night cycle.
            environment.drawClassicClouds = profile.DrawClassicClouds;
            environment.cloudScrollXLock = profile.CloudScrollXLock;
            environment.cloudScrollYLock = profile.CloudScrollYLock;
            m_environmentModule.FromLightShare(environment);
        }

        private void ApplyWind(WeatherKind weather)
        {
            if (!m_adjustWind || m_windModule == null)
                return;

            string plugin = m_windModule.WindActiveModelPluginName;
            if (string.IsNullOrEmpty(plugin))
                return;

            try
            {
                SaveWindParams(plugin);

                float strength = WeatherWindStrength(weather);
                if (plugin == "SimpleRandomWind")
                {
                    m_windModule.WindParamSet(plugin, "strength", strength * 4f);
                }
                else if (plugin == "ConfigurableWind")
                {
                    m_windModule.WindParamSet(plugin, "avgStrength", strength * 4f);
                    m_windModule.WindParamSet(plugin, "avgDirection", m_windDirectionDegrees);
                    m_windModule.WindParamSet(plugin, "varStrength", Math.Max(0.5f, strength * 1.6f));
                    m_windModule.WindParamSet(plugin, "varDirection", m_windDirectionVarianceDegrees);
                    m_windModule.WindParamSet(plugin, "rateChange", (weather == WeatherKind.Storm || weather == WeatherKind.Blizzard) ? 1.8f : 0.8f);
                }
            }
            catch (Exception e)
            {
                string regionName = m_scene == null ? "unknown region" : m_scene.RegionInfo.RegionName;
                m_log.WarnFormat("[WEATHER]: Could not apply weather wind in {0}: {1}", regionName, e.Message);
                throw;
            }
        }

        private void SaveWindParams(string plugin)
        {
            if (m_savedWindParams != null)
                return;

            Dictionary<string, float> saved = new Dictionary<string, float>();

            if (plugin == "SimpleRandomWind")
            {
                saved["strength"] = m_windModule.WindParamGet(plugin, "strength");
            }
            else if (plugin == "ConfigurableWind")
            {
                saved["avgStrength"] = m_windModule.WindParamGet(plugin, "avgStrength");
                saved["avgDirection"] = m_windModule.WindParamGet(plugin, "avgDirection");
                saved["varStrength"] = m_windModule.WindParamGet(plugin, "varStrength");
                saved["varDirection"] = m_windModule.WindParamGet(plugin, "varDirection");
                saved["rateChange"] = m_windModule.WindParamGet(plugin, "rateChange");
            }

            if (saved.Count == 0)
                return;

            m_savedWindPlugin = plugin;
            m_savedWindParams = saved;
        }

        private void RestoreWind(bool force)
        {
            if (m_savedWindParams == null || string.IsNullOrEmpty(m_savedWindPlugin))
                return;

            if (!force && !m_restoreWindOnClear)
                return;

            if (m_windModule == null)
                return;

            try
            {
                foreach (KeyValuePair<string, float> windParam in m_savedWindParams)
                    m_windModule.WindParamSet(m_savedWindPlugin, windParam.Key, windParam.Value);

                m_savedWindPlugin = null;
                m_savedWindParams = null;
            }
            catch (Exception e)
            {
                string regionName = m_scene == null ? "unknown region" : m_scene.RegionInfo.RegionName;
                m_log.WarnFormat("[WEATHER]: Could not restore weather wind in {0}: {1}", regionName, e.Message);
            }
        }

        private void RestoreClouds(bool force)
        {
            if (m_environmentModule == null)
                return;

            if (!force && !m_restoreCloudsOnClear)
                return;

            if (m_savedEnvironment == null)
            {
                // No in-session snapshot to restore to - most often because the
                // region restarted while weather was still active, so this
                // instance never captured a "before weather" baseline. Fall
                // back to a full reset so an explicit "weather clear" always
                // produces a clean sky instead of silently leaving whatever
                // dirty environment happened to be persisted from before.
                try
                {
                    if (m_scene != null)
                        m_environmentModule.ResetEnvironmentSettings(m_scene.RegionInfo.RegionID);
                }
                catch (Exception e)
                {
                    string regionName = m_scene == null ? "unknown region" : m_scene.RegionInfo.RegionName;
                    m_log.WarnFormat("[WEATHER]: Could not reset weather environment in {0}: {1}", regionName, e.Message);
                }
                return;
            }

            try
            {
                if (m_savedEnvironmentWasUnset && m_scene != null)
                    m_environmentModule.ResetEnvironmentSettings(m_scene.RegionInfo.RegionID);
                else
                    m_environmentModule.FromLightShare(m_savedEnvironment);

                m_savedEnvironment = null;
                m_savedEnvironmentWasUnset = false;
            }
            catch (Exception e)
            {
                string regionName = m_scene == null ? "unknown region" : m_scene.RegionInfo.RegionName;
                m_log.WarnFormat("[WEATHER]: Could not restore weather environment in {0}: {1}", regionName, e.Message);
            }
        }

        private bool RegionEnvironmentWasUnset()
        {
            Scene scene = m_scene;
            if (scene == null)
                return false;

            try
            {
                PropertyInfo property = scene.GetType().GetProperty(
                    "RegionEnvironment",
                    BindingFlags.Instance | BindingFlags.Public);

                return property != null && property.GetValue(scene, null) == null;
            }
            catch (Exception e)
            {
                m_log.DebugFormat(
                    "[WEATHER]: Could not determine whether {0} used the default region environment: {1}",
                    scene.RegionInfo.RegionName,
                    e.Message);
                return false;
            }
        }

        private static RegionLightShareData CloneLightShare(RegionLightShareData source)
        {
            return new RegionLightShareData
            {
                waterColor = source.waterColor,
                waterFogDensityExponent = source.waterFogDensityExponent,
                underwaterFogModifier = source.underwaterFogModifier,
                reflectionWaveletScale = source.reflectionWaveletScale,
                fresnelScale = source.fresnelScale,
                fresnelOffset = source.fresnelOffset,
                refractScaleAbove = source.refractScaleAbove,
                refractScaleBelow = source.refractScaleBelow,
                blurMultiplier = source.blurMultiplier,
                bigWaveDirection = source.bigWaveDirection,
                littleWaveDirection = source.littleWaveDirection,
                normalMapTexture = source.normalMapTexture,
                horizon = source.horizon,
                hazeHorizon = source.hazeHorizon,
                blueDensity = source.blueDensity,
                hazeDensity = source.hazeDensity,
                densityMultiplier = source.densityMultiplier,
                distanceMultiplier = source.distanceMultiplier,
                maxAltitude = source.maxAltitude,
                sunMoonColor = source.sunMoonColor,
                sunMoonPosition = source.sunMoonPosition,
                ambient = source.ambient,
                eastAngle = source.eastAngle,
                sunGlowFocus = source.sunGlowFocus,
                sunGlowSize = source.sunGlowSize,
                sceneGamma = source.sceneGamma,
                starBrightness = source.starBrightness,
                cloudColor = source.cloudColor,
                cloudXYDensity = source.cloudXYDensity,
                cloudCoverage = source.cloudCoverage,
                cloudScale = source.cloudScale,
                cloudDetailXYDensity = source.cloudDetailXYDensity,
                cloudScrollX = source.cloudScrollX,
                cloudScrollXLock = source.cloudScrollXLock,
                cloudScrollY = source.cloudScrollY,
                cloudScrollYLock = source.cloudScrollYLock,
                drawClassicClouds = source.drawClassicClouds
            };
        }

        private void DeleteEmitters(List<SceneObjectGroup> emitters)
        {
            if (m_scene == null)
                return;

            foreach (SceneObjectGroup emitter in emitters)
            {
                if (emitter == null || emitter.IsDeleted)
                    continue;

                try
                {
                    m_scene.DeleteSceneObject(emitter, false, false);
                }
                catch (Exception e)
                {
                    m_log.DebugFormat("[WEATHER]: Failed to delete weather emitter {0}: {1}", emitter.UUID, e.Message);
                }
            }
        }

        private static bool IsWeatherCommand(string request)
        {
            string[] tokens = CommandTokens(request);
            return tokens.Length > 0 && (tokens[0] == "weather" || tokens[0] == "meteo");
        }

        private bool TryResolveWeather(string request, out WeatherKind weather)
        {
            string token = WeatherToken(request);
            switch (token)
            {
                case "clear":
                case "stop":
                case "asciutto":
                    weather = WeatherKind.Clear;
                    return true;

                case "sunny":
                case "sun":
                case "sereno":
                case "sole":
                    weather = WeatherKind.Sunny;
                    return true;

                case "storm":
                case "temporale":
                case "tempesta":
                    weather = WeatherKind.Storm;
                    return true;

                case "snow":
                case "neve":
                case "nevica":
                    weather = WeatherKind.Snow;
                    return true;

                case "blizzard":
                case "snowstorm":
                case "bufera":
                    weather = WeatherKind.Blizzard;
                    return true;

                case "rain":
                case "pioggia":
                case "piove":
                    weather = WeatherKind.Rain;
                    return true;

                default:
                    weather = WeatherKind.Clear;
                    return false;
            }
        }

        private static bool IsStatusCommand(string request)
        {
            string[] tokens = CommandTokens(request);
            if (tokens.Length == 0)
                return false;

            if ((tokens[0] == "weather" || tokens[0] == "meteo") && tokens.Length == 1)
                return true;

            string token = WeatherToken(request);
            return token == "status" || token == "stato";
        }

        private static string WeatherToken(string request)
        {
            string[] tokens = CommandTokens(request);
            if (tokens.Length == 0)
                return string.Empty;

            if (tokens[0] == "weather" || tokens[0] == "meteo")
                return tokens.Length > 1 ? tokens[1] : string.Empty;

            return tokens[0];
        }

        private static string[] CommandTokens(string request)
        {
            return (request ?? string.Empty)
                .Trim()
                .ToLower(CultureInfo.InvariantCulture)
                .Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
        }

        private void SendStatus(IClientAPI client)
        {
            int emitterCount;
            int surfacePatchCount;
            int exclusionVolumeCount;
            WeatherKind weather;

            lock (m_weatherChangeSync)
            {
                lock (m_sync)
                {
                    emitterCount = m_emitters.Count;
                    exclusionVolumeCount = m_exclusionVolumes.Count;
                    weather = m_currentWeather;
                }

                surfacePatchCount = m_surfacePatches.Count;
            }

            SendReply(client, BuildWeatherReport(weather, emitterCount, exclusionVolumeCount, surfacePatchCount));
        }

        private string BuildWeatherReport(WeatherKind weather, int emitterCount, int exclusionVolumeCount, int surfacePatchCount)
        {
            Scene scene = m_scene;
            string regionName = scene == null ? "the region" : scene.RegionInfo.RegionName;
            float temperatureC = m_temperatureC;

            StringBuilder sb = new StringBuilder();
            sb.AppendFormat(CultureInfo.InvariantCulture, "Weather report for {0}: ", regionName);
            sb.Append(WeatherNarrative(weather));
            sb.AppendFormat(
                CultureInfo.InvariantCulture,
                " {0:0.#}C and {1}.",
                temperatureC,
                TemperatureDescriptor(temperatureC));

            if (IsPrecipitationWeather(weather))
            {
                sb.AppendFormat(
                    CultureInfo.InvariantCulture,
                    " Coverage: {0} ({1} emitters).",
                    CoverageModeName(m_coverageMode),
                    emitterCount);
            }

            if (m_surfaceEffectsEnabled)
            {
                sb.AppendFormat(
                    CultureInfo.InvariantCulture,
                    " Ground: {0:0}% wet, {1:0}% snow-covered.",
                    Clamp(m_wetnessLevel, 0f, 1f) * 100f,
                    Clamp(m_snowLevel, 0f, 1f) * 100f);
            }

            if (exclusionVolumeCount > 0)
            {
                sb.AppendFormat(
                    CultureInfo.InvariantCulture,
                    " {0} exclusion volume{1} active.",
                    exclusionVolumeCount,
                    exclusionVolumeCount == 1 ? string.Empty : "s");
            }

            sb.AppendFormat(CultureInfo.InvariantCulture, " Next forecast: {0}.", FormatNextForecast());

            return sb.ToString();
        }

        private static string WeatherNarrative(WeatherKind weather)
        {
            switch (weather)
            {
                case WeatherKind.Rain:
                    return "Rain is falling.";
                case WeatherKind.Storm:
                    return "A storm is raging, with heavy rain and lightning.";
                case WeatherKind.Snow:
                    return "Snow is falling.";
                case WeatherKind.Blizzard:
                    return "A blizzard is raging, with heavy snow and wind.";
                case WeatherKind.Sunny:
                    return "Skies are sunny and clear.";
                default:
                    return "Skies are clear.";
            }
        }

        private static string TemperatureDescriptor(float temperatureC)
        {
            if (temperatureC <= -10f)
                return "bitterly cold";
            if (temperatureC <= 0f)
                return "freezing";
            if (temperatureC <= 10f)
                return "cold";
            if (temperatureC <= 18f)
                return "cool";
            if (temperatureC <= 24f)
                return "mild";
            if (temperatureC <= 30f)
                return "warm";
            return "hot";
        }

        private void AnnounceWeatherChange(WeatherKind weather)
        {
            if (!m_announceWeatherInChat)
                return;

            Scene scene = m_scene;
            if (scene == null)
                return;

            int emitterCount;
            int exclusionVolumeCount;
            int surfacePatchCount;
            lock (m_weatherChangeSync)
            {
                lock (m_sync)
                {
                    emitterCount = m_emitters.Count;
                    exclusionVolumeCount = m_exclusionVolumes.Count;
                }

                surfacePatchCount = m_surfacePatches.Count;
            }

            string report = BuildWeatherReport(weather, emitterCount, exclusionVolumeCount, surfacePatchCount);
            scene.ForEachRootScenePresence(sp =>
            {
                if (sp != null && !sp.IsDeleted && sp.ControllingClient != null)
                    SendRegionWeatherMessage(sp, report);
            });
        }

        // "WEATHER|<kind>" on a fixed region-wide channel - the same shape
        // residents' own scripted FX prims (fireplaces, seasonal clothing,
        // umbrellas) already used before this module existed, so a receiver
        // built against that older convention keeps working unmodified. This
        // is the server-side equivalent of llRegionSay: IWorldComm is what
        // actually fans a message out to every llListen() registered on the
        // matching channel, the same delivery path llRegionSay itself uses.
        private void BroadcastWeatherToScripts(WeatherKind weather)
        {
            if (!m_broadcastWeatherToScripts)
                return;

            Scene scene = m_scene;
            if (scene == null)
                return;

            IWorldComm worldComm = scene.RequestModuleInterface<IWorldComm>();
            if (worldComm == null)
                return;

            string message = "WEATHER|" + BroadcastWeatherToken(weather);
            worldComm.DeliverMessage(
                ChatTypeEnum.Region, m_weatherBroadcastChannel, Name, scene.RegionInfo.RegionID, message);
        }

        // Deliberately separate from WeatherName() (lowercase, for human-
        // readable chat/log text) - existing FX receiver scripts compare
        // this token with an exact case-sensitive string match.
        private static string BroadcastWeatherToken(WeatherKind weather)
        {
            switch (weather)
            {
                case WeatherKind.Sunny:
                    return "Sunny";
                case WeatherKind.Rain:
                    return "Rain";
                case WeatherKind.Storm:
                    return "Storm";
                case WeatherKind.Snow:
                    return "Snow";
                case WeatherKind.Blizzard:
                    return "Blizzard";
                default:
                    return "Clear";
            }
        }

        private void UpdateTemperatureForWeather(WeatherKind weather)
        {
            float baseTemp = WeatherBaseTemperatureC(weather);
            float jitter = m_temperatureVarianceC > 0f
                ? RandomRange(-m_temperatureVarianceC, m_temperatureVarianceC)
                : 0f;
            m_temperatureC = Clamp(baseTemp + jitter, -100f, 100f);
        }

        private float WeatherBaseTemperatureC(WeatherKind weather)
        {
            switch (weather)
            {
                case WeatherKind.Sunny:
                    return m_sunnyTemperatureC;
                case WeatherKind.Rain:
                    return m_rainTemperatureC;
                case WeatherKind.Storm:
                    return m_stormTemperatureC;
                case WeatherKind.Snow:
                    return m_snowTemperatureC;
                case WeatherKind.Blizzard:
                    return m_blizzardTemperatureC;
                default:
                    return m_clearTemperatureC;
            }
        }

        private void SendWeatherIM(UUID agentID)
        {
            Scene scene = m_scene;
            if (scene == null || string.IsNullOrEmpty(m_weatherIMMessage))
                return;

            ScenePresence sp = scene.GetScenePresence(agentID);
            if (sp == null || sp.IsDeleted || sp.IsNPC || sp.IsChildAgent || sp.ControllingClient == null)
                return;

            GridInstantMessage msg = new GridInstantMessage
            {
                imSessionID = UUID.Random().Guid,
                fromAgentID = UUID.Zero.Guid,
                toAgentID = agentID.Guid,
                timestamp = (uint)Util.UnixTimeSinceEpoch(),
                fromAgentName = "Weather",
                message = FormatWeatherIMMessage(scene),
                dialog = (byte)InstantMessageDialog.MessageFromAgent,
                fromGroup = false,
                offline = (byte)0,
                ParentEstateID = 0,
                Position = sp.AbsolutePosition,
                RegionID = scene.RegionInfo.RegionID.Guid,
                binaryBucket = Array.Empty<byte>()
            };

            sp.ControllingClient.SendInstantMessage(msg);
        }

        private string FormatForecastWarningMessage(Scene scene, WeatherKind nextWeather)
        {
            return m_autoCycleForecastWarningMessage
                .Replace("{RegionName}", scene.RegionInfo.RegionName)
                .Replace("{NextWeather}", WeatherName(nextWeather))
                .Replace("{NextTemperature}", WeatherBaseTemperatureC(nextWeather).ToString("0.#", CultureInfo.InvariantCulture))
                .Replace("{TimeUntilNextForecast}", FormatTimeUntilNextForecast())
                .Replace("{NextForecast}", FormatNextForecast());
        }

        private void SendRegionWeatherMessage(ScenePresence sp, string message)
        {
            sp.ControllingClient.SendChatMessage(
                message,
                (byte)ChatTypeEnum.Region,
                Vector3.Zero,
                "Weather",
                UUID.Zero,
                UUID.Zero,
                (byte)ChatSourceType.Object,
                (byte)ChatAudibleLevel.Fully);
        }

        private string FormatWeatherIMMessage(Scene scene)
        {
            int emitterCount;
            WeatherKind weather;
            lock (m_sync)
            {
                emitterCount = m_emitters.Count;
                weather = m_currentWeather;
            }

            return m_weatherIMMessage
                .Replace("{RegionName}", scene.RegionInfo.RegionName)
                .Replace("{Weather}", WeatherName(weather))
                .Replace("{Temperature}", m_temperatureC.ToString("0.#", CultureInfo.InvariantCulture))
                .Replace("{EmitterCount}", emitterCount.ToString(CultureInfo.InvariantCulture))
                .Replace("{AutoCycle}", m_autoCycleEnabled ? string.Format(CultureInfo.InvariantCulture, "{0:0.##}h", m_autoCycleHours) : "off")
                .Replace("{NextForecast}", FormatNextForecast());
        }

        private string FormatNextForecast()
        {
            if (!m_autoCycleEnabled)
                return "manual updates only";

            string timeUntil = FormatTimeUntilNextForecast();
            if (string.IsNullOrEmpty(timeUntil))
                return "scheduled shortly";

            return "in " + timeUntil;
        }

        private string FormatTimeUntilNextForecast()
        {
            long nextTicks = m_nextAutoCycleTicks;
            if (nextTicks <= 0)
                return string.Empty;

            TimeSpan remaining = new TimeSpan(Math.Max(0, nextTicks - DateTime.Now.Ticks));
            if (remaining.TotalSeconds < 60)
                return "less than 1 minute";

            int hours = (int)Math.Floor(remaining.TotalHours);
            int minutes = remaining.Minutes;
            if (hours > 0 && minutes > 0)
                return string.Format(CultureInfo.InvariantCulture, "{0} hour{1} {2} minute{3}", hours, hours == 1 ? string.Empty : "s", minutes, minutes == 1 ? string.Empty : "s");
            if (hours > 0)
                return string.Format(CultureInfo.InvariantCulture, "{0} hour{1}", hours, hours == 1 ? string.Empty : "s");

            return string.Format(CultureInfo.InvariantCulture, "{0} minute{1}", Math.Max(1, minutes), minutes == 1 ? string.Empty : "s");
        }

        private static string CoverageModeName(CoverageMode mode)
        {
            switch (mode)
            {
                case CoverageMode.ActiveArea:
                    return "active-area";
                case CoverageMode.Wandering:
                    return "wandering";
                default:
                    return "region";
            }
        }

        private static string WeatherName(WeatherKind weather)
        {
            switch (weather)
            {
                case WeatherKind.Rain:
                    return "rain";
                case WeatherKind.Storm:
                    return "storm";
                case WeatherKind.Snow:
                    return "snow";
                case WeatherKind.Blizzard:
                    return "blizzard";
                case WeatherKind.Sunny:
                    return "sunny";
                default:
                    return "clear";
            }
        }

        private CoverageMode ParseCoverageMode(string value)
        {
            string normalized = (value ?? string.Empty).Trim();

            if (string.Equals(normalized, "Region", StringComparison.OrdinalIgnoreCase))
                return CoverageMode.Region;

            if (string.Equals(normalized, "ActiveArea", StringComparison.OrdinalIgnoreCase)
                || string.Equals(normalized, "Active-Area", StringComparison.OrdinalIgnoreCase)
                || string.Equals(normalized, "Active_Area", StringComparison.OrdinalIgnoreCase))
            {
                return CoverageMode.ActiveArea;
            }

            if (string.Equals(normalized, "Wandering", StringComparison.OrdinalIgnoreCase))
                return CoverageMode.Wandering;

            m_log.WarnFormat(
                "[WEATHER]: CoverageMode '{0}' is invalid; using Region coverage.",
                normalized);
            return CoverageMode.Region;
        }

        private UUID ReadTexture(IConfig config, string key, UUID fallback)
        {
            string value = config.GetString(key, string.Empty).Trim();
            if (string.IsNullOrEmpty(value))
                return fallback;

            if (UUID.TryParse(value, out UUID texture))
                return texture;

            m_log.WarnFormat("[WEATHER]: {0} '{1}' is not a valid UUID; using fallback texture {2}.", key, value, fallback);
            return fallback;
        }

        private WeatherKind CurrentWeather()
        {
            lock (m_sync)
                return m_currentWeather;
        }

        private static bool IsPrecipitationWeather(WeatherKind weather)
        {
            return weather == WeatherKind.Rain || weather == WeatherKind.Storm
                || weather == WeatherKind.Snow || weather == WeatherKind.Blizzard;
        }

        private void SendReply(IClientAPI client, string message)
        {
            client.SendChatMessage(
                message,
                (byte)ChatTypeEnum.Owner,
                Vector3.Zero,
                "Weather",
                UUID.Zero,
                UUID.Zero,
                (byte)ChatSourceType.Object,
                (byte)ChatAudibleLevel.Fully);
        }

        private static float Clamp(float value, float min, float max)
        {
            if (value < min)
                return min;
            if (value > max)
                return max;
            return value;
        }

        private static int Clamp(int value, int min, int max)
        {
            if (value < min)
                return min;
            if (value > max)
                return max;
            return value;
        }
    }
}
